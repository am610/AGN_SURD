from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
base=root/'analysis/component_revision'
commands=[
 [base/'rankings/rank_components.py','--data-dir',root/'data','--out-dir',base/'rankings'],
 [base/'rankings/build_common_tables.py'],
 [base/'calculate_directed_unique_peaks.py'],
 [base/'build_selected_tables.py'],
 [base/'figures/plot_specific_components.py','--data-dir',root/'data','--output-dir',root/'figures'],
 [base/'build_revision.py'],
 [base/'build_supplement.py'],
]
for command in commands:
 subprocess.run([sys.executable]+[str(x) for x in command],cwd=root,check=True)
print('Rebuilt named-component rankings, figure data and manuscript sources. Compile the TeX files to update PDFs.')
