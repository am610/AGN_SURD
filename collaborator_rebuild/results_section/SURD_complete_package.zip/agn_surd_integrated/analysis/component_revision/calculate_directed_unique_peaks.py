"""Reaggregate archived SURD unique components; no new SURD fit or significance test."""
from pathlib import Path
import pandas as pd
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
BASE=ROOT/'data'
c = pd.read_csv(BASE / 'individual_components.csv.gz')
s = pd.read_csv(BASE / 'support_and_leakage.csv')
keys = ['epoch', 'subset', 'target', 'config', 'bins', 'lag_days']
d = c.merge(s, on=keys, validate='many_to_one')
d['g'] = d.fraction * (1 - d.normalized_leakage)
u = d[(d.config == 'common') & (d.kind == 'U')].copy()
u['source'] = u.component.str[2:-1]
u = u[u.source != u.target]
rows = []
for metric, selection in [('fraction', 'fmax'), ('g', 'gmax')]:
    for _, v in u.groupby(['epoch', 'subset', 'target', 'bins', 'source']):
        v = v.sort_values('lag_days')
        r = v.loc[v[metric].idxmax()].copy()
        r['selection'] = selection
        r['zero_curve'] = bool(v.fraction.eq(0).all())
        r['peak_lag_observed_days'] = float(r.lag_days) if not r.zero_curve else float('nan')
        r['peak_lag_rest_days'] = r.peak_lag_observed_days / 1.01717
        if r.zero_curve:
            # No lag or concurrent leakage is defined by a zero plateau.
            for key in ['lag_days', 'normalized_leakage', 'tuple_count', 'occupied_cells', 'joint_mi_bits']:
                r[key] = float('nan')
        rows.append(r)
result = pd.DataFrame(rows)
result.to_csv(OUT / 'directed_unique_peaks.csv', index=False)
selected = result[(result.epoch == 1992) & (result.selection == 'gmax') & (result.source == 'red') & result.target.isin(['blue', 'core', 'total'])]
selected.to_csv(OUT / '1992_red_unique_peaks.csv', index=False)
print('Wrote', len(result), 'nonself unique-peak rows and', len(selected), '1992 red-source rows.')
