from pathlib import Path
import re
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OUT=ROOT
text=r'''\documentclass[10pt,a4paper]{article}
\usepackage[margin=19mm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{newtxtext,newtxmath}
\usepackage{amsmath,booktabs,graphicx,capt-of,hyperref}
\hypersetup{colorlinks=true,linkcolor=blue}
\renewcommand{\thetable}{S\arabic{table}}
\pagestyle{plain}
\setlength{\parindent}{0pt}
\begin{document}
\begin{center}
{\large\bfseries Supplementary named-component catalogue for NGC 5548}\\[4pt]
Ayan Mitra and Vasilios Zarikas
\end{center}
This catalogue accompanies the seasonal SURD analysis. Tables S1--S2 give common-lag unique self-history maxima, separated from the cross-variable results in the main paper. Tables S3--S14 give the three leading named cross-unique, redundant and synergistic components for every unequal-lag case. Each entry lists $a:f_a/g_a/\ell\;(L)$ at that atom's own maximum $g_a=I_a/H(Y)=(1-\ell)f_a$. Peaks at different lags must not be added. The base lag $L$ is in observed days; the shifted wing is sampled at $L+5$ days. F5100 and total sets retain the notation $(F,B,C,R)$ and $(H,B,C,R)$. All values are recalculated from the archived CSVs; full-precision values and alternative $f_a$ maxima are supplied with the source package.

'''
def fixed(name):
    x=(BASE/'rankings/tables'/f'{name}.tex').read_text()
    x=x.replace(r'\begin{table*}[p]',r'\begin{minipage}{\textwidth}').replace(r'\end{table*}',r'\end{minipage}')
    x=x.replace(r'\caption{',r'\captionof{table}{')
    x=x.replace(r'\scriptsize',r'\footnotesize')
    x=re.sub(r'Table~\\ref\{[^}]+\}', 'the definitions above',x)
    return x
for subset in ['total_wings','continuum_wings']:
    text+='\n'+fixed('self_unique_'+subset)+'\n\\medskip\n'
for config in ['blue_leading','red_leading']:
    for family in ['cross_u','synergistic','redundant']:
        for subset in ['total_wings','continuum_wings']:
            text+='\n\\clearpage\n'+fixed('_'.join([family,subset,config]))+'\n'
text+='\n\\end{document}\n'
(OUT/'agn_surd_component_supplement.tex').write_text(text)
print('Wrote supplementary catalogue.')
