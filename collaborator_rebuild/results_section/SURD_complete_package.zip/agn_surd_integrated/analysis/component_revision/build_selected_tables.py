from pathlib import Path
import pandas as pd

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OUT=BASE/'tables';OUT.mkdir(exist_ok=True)
d=pd.read_csv(BASE/'rankings/all_atom_extrema.csv')
sym={'total':'H','continuum':'F','blue':'B','core':'C','red':'R'}
def atom(x):
    k,a=x[:-1].split('(')
    return k+'('+','.join(sym[v] for v in a.split(','))+')'
def tab(name,caption,cols,head,rows):
    s='\\begin{SURDtable}\n\\centering\n\\caption{'+caption+'}\n\\label{tab:'+name+'}\n\\small\n\\begin{tabular}{'+cols+'}\n\\toprule\n'+head+r' \\'+'\n\\midrule\n'+'\n'.join(rows)+'\n\\bottomrule\n\\end{tabular}\n\\end{SURDtable}\n'
    (OUT/(name+'.tex')).write_text(s)
def row(x):return ' & '.join(x)+r' \\'
def get(e,s,t,c,b,a):
    q=d[(d.epoch==e)&(d.subset==s)&(d.target==t)&(d.config==c)&(d.bins==b)&(d.component==a)]
    assert len(q)==1
    return q.iloc[0]
rows=[];exact=[]
for s,t in [('continuum_wings','blue'),('total_wings','blue'),('total_wings','total')]:
    for b in [2,3]:
        r=get(1992,s,t,'common',b,'U(red)');exact.append(r)
        rows.append(row(['F5100' if s=='continuum_wings' else 'Total','$'+sym[t]+'$',str(b),'$U(R)$',str(int(r.gmax_lag_days)),f'{r.gmax_fraction:.3f}',f'{r.gmax_g:.3f}',f'{r.gmax_normalized_leakage:.3f}']))
tab('directed_1992','Unique red-wing contributions in 1992 with common lags. Values refer to the maximum $g_a$ of the named component, with simultaneous $f_a$ and leakage. Lags are observed days. These resolve the red-to-blue channel in both subsets and the red-to-total channel in the total set.','lcccrrrr',r'Set & Target & Bins & Component & $L$ & $f$ & $g$ & $\ell$',rows)
pd.DataFrame(exact).to_csv(OUT/'directed_1992_exact.csv',index=False)

examples=[
 (1989,'continuum_wings','core','blue_leading','U(continuum)'),
 (1989,'continuum_wings','core','red_leading','U(continuum)'),
 (1989,'continuum_wings','core','red_leading','R(blue,core)'),
 (1990,'continuum_wings','core','blue_leading','R(core,red)'),
 (1990,'continuum_wings','blue','blue_leading','S(continuum,blue)'),
 (1991,'continuum_wings','core','red_leading','S(continuum,red)'),
 (1991,'total_wings','blue','blue_leading','S(core,red)'),
 (1992,'continuum_wings','blue','blue_leading','U(red)'),
 (1992,'continuum_wings','blue','red_leading','U(red)'),
 (1992,'total_wings','blue','blue_leading','U(red)'),
 (1992,'total_wings','blue','red_leading','U(red)'),
 (1992,'continuum_wings','core','blue_leading','R(core,red)'),
 (1993,'continuum_wings','core','blue_leading','S(continuum,red)'),
 (1993,'total_wings','blue','red_leading','S(blue,core,red)')]
rows=[];exact=[]
for e,s,t,c,a in examples:
    vals=[str(e),'F' if s=='continuum_wings' else 'H','$'+sym[t]+'$','$B+5$' if c=='blue_leading' else '$R+5$','$'+atom(a)+'$']
    for b in [2,3]:
        r=get(e,s,t,c,b,a);exact.append(r)
        if r.identically_zero:vals.append('--')
        else:vals.append(f'$({int(r.gmax_lag_days)};{r.gmax_fraction:.3f},{r.gmax_g:.3f},{r.gmax_normalized_leakage:.3f})$')
    rows.append(row(vals))
tab('selected_mixed',r"Selected named components with unequal predictor lags. Each entry is $(L;f,g,\ell)$ at that component's own maximum $g$, separately for each state count. H and F denote the total and F5100 sets. B+5 or R+5 samples the indicated wing at $L+5$ days while other histories are sampled at $L$. A dash denotes a component that is zero throughout the scan. The supplementary catalogue covers every target and all leading components.",'cccllll',r'Epoch & Set & Target & Offset & Component & Two bins: $(L;f,g,\ell)$ & Three bins: $(L;f,g,\ell)$',rows)
pd.DataFrame(exact).to_csv(OUT/'selected_mixed_exact.csv',index=False)

raw=ROOT/'data'
k=['epoch','subset','target','config','bins','lag_days']
c=pd.read_csv(raw/'individual_components.csv.gz')
s=pd.read_csv(raw/'support_and_leakage.csv')
z=c.merge(s,on=k,validate='many_to_one');z['g']=z.fraction*(1-z.normalized_leakage)
cases=[(1989,'continuum_wings','core','common',24),(1991,'continuum_wings','core','common',4),(1991,'continuum_wings','core','common',20),(1992,'total_wings','red','red_leading',30),(1992,'total_wings','core','red_leading',30),(1993,'total_wings','core','common',27)]
rows=[];exact=[]
for e,ss,t,cc,L in cases:
    vals=[str(e),'F' if ss=='continuum_wings' else 'H','$'+sym[t]+'$','Common' if cc=='common' else '$R+5$',str(L)]
    for b in [2,3]:
        q=z[(z.epoch==e)&(z.subset==ss)&(z.target==t)&(z.config==cc)&(z.lag_days==L)&(z.bins==b)&(z.kind=='S')]
        r=q.loc[q.g.idxmax()];exact.append(r)
        vals.extend([f'{r.normalized_leakage:.3f}',f'${atom(r.component)}:{r.fraction:.3f}/{r.g:.3f}$'])
    rows.append(row(vals))
tab('leakage_cases','Leakage at selected fixed target--lag configurations, paired with the largest individual synergy at that same point. Both state counts use the displayed base lag. The synergy entries are $a:f_a/g_a$; these are not maxima over lag. F and H identify the F5100 and total sets. A leakage printed as 0.000 is zero to the displayed precision.','ccclrrlrl',r'& & & & & \multicolumn{2}{c}{Two bins} & \multicolumn{2}{c}{Three bins} \\ \cmidrule(lr){6-7}\cmidrule(lr){8-9} Epoch & Set & Target & Configuration & $L$ & $\ell$ & Leading $S$: $f/g$ & $\ell$ & Leading $S$: $f/g$',rows)
pd.DataFrame(exact).to_csv(OUT/'leakage_cases_exact.csv',index=False)
print('Built three selected-results tables.')
