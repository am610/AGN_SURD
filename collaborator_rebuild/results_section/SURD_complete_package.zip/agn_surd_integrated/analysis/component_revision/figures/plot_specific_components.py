#!/usr/bin/env python3
"""Reproduce the named-component SURD figure from the archived numerical scans.

Example:
  python plot_specific_components.py --data-dir ../data --output-dir .

No SURD estimates are recomputed or modified. Each displayed component is
g = (1 - normalized_leakage) * fraction at the same target and base lag.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import numpy as np
import pandas as pd


KEYS = ["epoch", "subset", "target", "config", "bins", "lag_days"]
SOURCE_COMMIT = "895a826512cc2f866035cc5b7b4430e35f28ab44"
BLUE = "#0072B2"
ORANGE = "#D55E00"
GREEN = "#009E73"
PURPLE = "#AA4499"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path,
                        default=Path(__file__).resolve().parent.parent / "data")
    parser.add_argument("--output-dir", type=Path,
                        default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    atom_file = args.data_dir / "individual_components.csv.gz"
    support_file = args.data_dir / "support_and_leakage.csv"
    atoms = pd.read_csv(atom_file)
    support = pd.read_csv(support_file)
    assert not support.duplicated(KEYS).any()
    data = atoms.merge(support, on=KEYS, how="left", validate="many_to_one")
    assert data.normalized_leakage.notna().all()
    data["entropy_fraction"] = data.fraction * (1 - data.normalized_leakage)
    assert np.allclose(data.bits / data.joint_mi_bits, data.fraction,
                       rtol=1e-12, atol=1e-12)

    plt.rcParams.update({
        "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix", "font.size": 9,
        "axes.titlesize": 10, "axes.labelsize": 9,
        "xtick.labelsize": 8, "ytick.labelsize": 8,
        "legend.fontsize": 7.5, "axes.linewidth": 0.6,
        "lines.linewidth": 1.7, "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.facecolor": "white", "figure.facecolor": "white",
    })
    fig, axes = plt.subplots(3, 2, figsize=(7.2, 8.0))
    fig.subplots_adjust(left=0.085, right=0.985, bottom=0.065, top=0.95,
                        wspace=0.22, hspace=0.42)
    exported = []
    extrema = []

    def select(epoch, subset, target, bins, component):
        result = data[(data.epoch == epoch) & (data.subset == subset)
                      & (data.target == target) & (data.bins == bins)
                      & (data.config == "common")
                      & (data.component == component)].sort_values("lag_days")
        assert len(result) == 30 and result.lag_days.tolist() == list(range(1, 31))
        return result

    def save_component(q, panel, display_label):
        out = q[KEYS + ["component", "bits", "fraction", "entropy_fraction",
                       "normalized_leakage", "joint_mi_bits", "tuple_count"]].copy()
        out.insert(0, "panel", panel)
        out.insert(1, "display_label", display_label)
        out["plotted_quantity"] = "entropy_fraction"
        out["plotted_value"] = out.entropy_fraction
        exported.append(out)
        if q.entropy_fraction.max() > 0:
            row = q.loc[q.entropy_fraction.idxmax()]
            extrema.append({"panel": panel, "display_label": display_label,
                            **{k: row[k] for k in KEYS},
                            "component": row.component, "peak_g": row.entropy_fraction,
                            "fraction_at_peak_g": row.fraction,
                            "leakage_at_peak_g": row.normalized_leakage,
                            "is_identically_zero": False})
        else:
            row = q.iloc[0]
            extrema.append({"panel": panel, "display_label": display_label,
                            **{k: row[k] if k != "lag_days" else None for k in KEYS},
                            "component": row.component, "peak_g": 0.0,
                            "fraction_at_peak_g": 0.0,
                            "leakage_at_peak_g": None,
                            "is_identically_zero": True})

    def save_leakage(q, panel, display_label):
        out = q[KEYS + ["normalized_leakage", "joint_mi_bits", "tuple_count"]].copy()
        out.insert(0, "panel", panel)
        out.insert(1, "display_label", display_label)
        out["component"] = "leakage"
        out["plotted_quantity"] = "normalized_leakage"
        out["plotted_value"] = out.normalized_leakage
        exported.append(out)

    top_components = [
        ("R(continuum,blue,core,red)", r"$g_{R(F,B,C,R)\to C}$", GREEN, "-"),
        ("S(continuum,blue)", r"$g_{S(F,B)\to C}$", BLUE, "-"),
        ("S(continuum,red)", r"$g_{S(F,R)\to C}$", ORANGE, "-"),
        ("U(continuum)", r"$g_{U(F)\to C}$", PURPLE, ":"),
    ]
    for col, bins in enumerate([2, 3]):
        panel = "ab"[col]
        ax = axes[0, col]
        for component, label, color, linestyle in top_components:
            q = select(1991, "continuum_wings", "core", bins, component)
            ax.plot(q.lag_days, q.entropy_fraction, color=color,
                    linestyle=linestyle, label=label, zorder=3)
            save_component(q, panel, label)
        ax.plot(q.lag_days, q.normalized_leakage, color="#333333",
                linestyle=(0, (4, 2)), linewidth=1.35,
                label=r"$\ell_C$", zorder=2)
        save_leakage(q, panel, r"$\ell_C$")
        ax.set_title(f"({panel}) 1991 core $C$, F5100 set: {bins} bins", pad=7)
        ax.set_ylim(-0.012, 0.61)
        ax.yaxis.set_major_locator(MultipleLocator(0.1))
        ax.set_ylabel("Target-entropy fraction")
        ax.legend(loc="upper left", ncol=2, frameon=True,
                  framealpha=0.96, edgecolor="white", handlelength=2.3,
                  columnspacing=1.0, borderpad=0.3)
        if bins == 2:
            ax.text(29.0, 0.021, r"$g_{U(F)\to C}=0$", color=PURPLE,
                    ha="right", va="bottom", fontsize=8)

        panel = "cd"[col]
        ax = axes[1, col]
        for subset, set_label, color, forward_marker, reverse_marker, markoffset in [
            ("continuum_wings", "F5100 set", BLUE, "o", "^", 0),
            ("total_wings", "Total set", ORANGE, "s", "v", 2),
        ]:
            q = select(1992, subset, "blue", bins, "U(red)")
            label = rf"{set_label}: $U(R)\to B$"
            ax.plot(q.lag_days, q.entropy_fraction, color=color, label=label,
                    zorder=3)
            peak = q.loc[q.entropy_fraction.idxmax()]
            ax.plot(peak.lag_days, peak.entropy_fraction, marker=forward_marker,
                    color=color, markersize=4, linestyle="none", zorder=4)
            save_component(q, panel, label)
            q = select(1992, subset, "red", bins, "U(blue)")
            assert (q.entropy_fraction == 0).all()
            label = rf"{set_label}: $U(B)\to R$"
            ax.plot(q.lag_days, q.entropy_fraction, color=color, linestyle=":",
                    marker=reverse_marker, markevery=(markoffset, 4),
                    markersize=3.5, markerfacecolor="white", markeredgewidth=0.9,
                    label=label, zorder=3)
            save_component(q, panel, label)
        ax.set_title(f"({panel}) 1992 wing-unique terms: {bins} bins", pad=7)
        ax.set_ylim(-0.007, 0.237)
        ax.yaxis.set_major_locator(MultipleLocator(0.05))
        ax.set_ylabel("Target-entropy fraction")
        ax.legend(loc="upper right", ncol=1, frameon=True,
                  framealpha=0.97, edgecolor="white", handlelength=2.7,
                  labelspacing=0.25, borderpad=0.25, fontsize=7.4)

        panel = "ef"[col]
        ax = axes[2, col]
        for subset, set_label, color in [
            ("continuum_wings", "F5100 set", BLUE),
            ("total_wings", "Total set", ORANGE),
        ]:
            for target, target_symbol, linestyle in [("blue", "B", "-"),
                                                    ("red", "R", (0, (4, 2)))]:
                component = "U(red)" if target == "blue" else "U(blue)"
                q = select(1992, subset, target, bins, component)
                label = rf"{set_label}: $\ell_{target_symbol}$"
                ax.plot(q.lag_days, q.normalized_leakage, color=color,
                        linestyle=linestyle, label=label, zorder=3)
                save_leakage(q, panel, label)
        ax.set_title(f"({panel}) 1992 leakage by target: {bins} bins", pad=7)
        ax.set_ylim(0, 1.02)
        ax.yaxis.set_major_locator(MultipleLocator(0.2))
        ax.set_ylabel("Normalized leakage")
        ax.legend(loc="upper left", ncol=1, frameon=True,
                  framealpha=0.97, edgecolor="white", handlelength=2.7,
                  labelspacing=0.3, borderpad=0.25)

    for row in axes:
        for ax in row:
            ax.set_xlim(1, 30)
            ax.set_xticks([1, 5, 10, 15, 20, 25, 30])
            ax.set_xlabel("Common base lag $L$ [observed days]")
            ax.grid(axis="y", color="#dddddd", linewidth=0.45, zorder=0)
            ax.tick_params(direction="in", length=3, width=0.55,
                           top=True, right=True)
    fig.savefig(args.output_dir / "specific_components.pdf")
    fig.savefig(args.output_dir / "specific_components.png", dpi=240)
    plt.close(fig)
    pd.concat(exported, ignore_index=True).to_csv(
        args.output_dir / "specific_components_plot_data.csv", index=False)
    pd.DataFrame(extrema).to_csv(
        args.output_dir / "specific_components_peak_checks.csv", index=False)
    metadata = {
        "source_commit": SOURCE_COMMIT,
        "source_repository": "https://github.com/am610/AGN_SURD",
        "inputs": {str(p.name): hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in [atom_file, support_file]},
        "config": "common", "bin_choices": [2, 3],
        "formula": "entropy_fraction = fraction * (1 - normalized_leakage)",
        "interpretation": "Named observational SURD components; no significance test or direct physical coupling inference",
        "peak_rule": "Maximum entropy_fraction over L=1,...,30; no maximizing lag assigned to identically zero terms",
        "panels": {"a,b": "1991 F5100-set core target: four named components and its own leakage",
                   "c,d": "1992 wing-target unique components in both variable sets; markers denote forward maxima or distinguish zero reverse curves",
                   "e,f": "1992 blue/red target leakage in both sets; solid=blue target, dashed=red target"},
        "plotted_rows": int(sum(len(x) for x in exported)),
    }
    (args.output_dir / "specific_components_provenance.json").write_text(
        json.dumps(metadata, indent=2) + "\n")
    print(json.dumps({"output": str(args.output_dir.resolve()),
                      "plotted_rows": metadata["plotted_rows"],
                      "peak_rows": len(extrema)}, indent=2))


if __name__ == "__main__":
    main()
