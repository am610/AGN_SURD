from pathlib import Path
import pandas as pd, numpy as np
O=Path(__file__).resolve().parent; P=O.parents[1]/'data'
keys=['epoch','subset','target','config','bins','lag_days'];scan=keys[:-1]
c=pd.read_csv(P/'individual_components.csv.gz');s=pd.read_csv(P/'support_and_leakage.csv')
d=c.merge(s,on=keys,validate='many_to_one');d['ell']=d.normalized_leakage;d['g']=d.fraction*(1-d.ell);d['members']=d.component.str.extract(r'\((.*)\)')[0];d['group_size']=d.members.str.count(',')+1
d['self_unique']=d.kind.eq('U')&d.members.eq(d.target)
bud=d.groupby(keys+['kind']).g.sum().unstack().rename(columns=lambda v:'budget_'+v+'_g').reset_index()
for source in ['continuum','total','blue','core','red']:
 for kind,tag in [('U','U'),('S','involving_S'),('R','involving_R')]:
  v=d[(d.kind==kind)&d.members.str.split(',').apply(lambda q:source in q)].groupby(keys).g.sum().rename(source+'_'+tag+'_g').reset_index();bud=bud.merge(v,on=keys,how='left')
for first,second,tag in [('blue','core','BC'),('blue','red','BR'),('core','red','CR')]:
 v=d[(d.kind=='R')&d.members.str.split(',').apply(lambda q:first in q and second in q)].groupby(keys).g.sum().rename(tag+'_inclusive_R_g').reset_index();bud=bud.merge(v,on=keys,how='left')
bud=bud.fillna(0)
rows=[]
for comp in ['R(blue,core)','R(blue,red)','R(core,red)']:
 x=d[d.component==comp]
 for metric in ['fraction','g']:
  r=x.loc[x.groupby(scan)[metric].idxmax()].copy();r['analysis_type']='pair_peak';r['selection_metric']=metric;rows.append(r)
x=d[(d.kind=='R')&(d.group_size>=3)]
for metric in ['fraction','g']:
 r=x.loc[x.groupby(scan)[metric].idxmax()].copy();r['analysis_type']='largest_group_peak';r['selection_metric']=metric;rows.append(r)
# extrema of leakage and simultaneous atom peaks, per scan
for ex,ix in [('minimum',s.groupby(scan).normalized_leakage.idxmin()),('maximum',s.groupby(scan).normalized_leakage.idxmax())]:
 loc=s.loc[ix,keys].copy();x=d.merge(loc,on=keys,how='inner')
 for label,y in [('U_all',x[x.kind=='U']),('U_cross',x[(x.kind=='U')&~x.self_unique]),('R',x[x.kind=='R']),('S',x[x.kind=='S'])]:
  r=y.loc[y.groupby(scan).g.idxmax()].copy();r['analysis_type']='leakage_'+ex;r['selection_metric']='simultaneous_top_'+label;rows.append(r)
a=pd.concat(rows,ignore_index=True)
a['zero_component_at_selected_lag']=a.fraction.eq(0)
a=a.merge(bud,on=keys,how='left',validate='many_to_one')
cols=['analysis_type','selection_metric']+keys+['component','kind','members','group_size','bits','fraction','g','ell','tuple_count','joint_mi_bits','zero_component_at_selected_lag']+[v for v in bud.columns if v not in keys]
a[cols].sort_values(['analysis_type','subset','epoch','target','config','bins','selection_metric','component']).to_csv(O/'redundancy_leakage.csv',index=False)
# Pair maxima matched across bins, retaining separate maximizing lags
pp=a[(a.analysis_type=='pair_peak')&(a.selection_metric=='g')]
match=['epoch','subset','target','config','component']
x=pp[pp.bins==2].merge(pp[pp.bins==3],on=match,suffixes=['_2','_3']);x['min_crossbin_peak_g']=x[['g_2','g_3']].min(axis=1);x.sort_values('min_crossbin_peak_g',ascending=False).to_csv(O/'redundancy_pair_crossbin.csv',index=False)
print('RECORDS',len(a),'crossbin pairs',len(x))
for pair in ['R(blue,core)','R(blue,red)','R(core,red)']:
 print('\nGLOBALg pair',pair)
 y=pp[pp.component==pair];show=y.loc[y.groupby('bins').g.idxmax()]
 print(show[['epoch','subset','target','config','bins','lag_days','component','fraction','g','ell','tuple_count']].to_string(index=False))
 print('TOProbustcrossbin')
 print(x[x.component==pair].sort_values('min_crossbin_peak_g',ascending=False)[match+['lag_days_2','fraction_2','g_2','ell_2','lag_days_3','fraction_3','g_3','ell_3']].head(5).to_string(index=False))
print('\nGLOBAL leakage extrema')
for bins in [2,3]:
 for ex in ['minimum','maximum']:
  idx=s[s.bins==bins].normalized_leakage.idxmin() if ex=='minimum' else s[s.bins==bins].normalized_leakage.idxmax();r=s.loc[idx];q=a[(a.analysis_type=='leakage_'+ex)]
  for k in scan:q=q[q[k]==r[k]]
  print(ex,bins,q[['epoch','subset','target','config','bins','lag_days','component','fraction','g','ell','tuple_count']].to_string(index=False))
# Same-lag cross-bin examples for interpretation and omission diagnostics.
examples=[
 ('R_BC_stable',1989,'continuum_wings','core','red_leading',1,'R(blue,core)'),
 ('R_CR_shifted',1992,'continuum_wings','core','blue_leading',2,'R(core,red)'),
 ('R_CR_other_epoch',1990,'continuum_wings','core','blue_leading',5,'R(core,red)'),
 ('R_BR_small',1990,'continuum_wings','blue','common',8,'R(blue,red)'),
 ('fourway_1992',1992,'total_wings','blue','common',2,'R(total,blue,core,red)'),
 ('threeway_1991',1991,'continuum_wings','blue','common',4,'R(blue,core,red)'),
 ('omission_candidate_local',1991,'continuum_wings','core','blue_leading',1,'R(blue,core)'),
 ('omission_candidate_later',1991,'continuum_wings','core','blue_leading',20,'R(blue,core)'),
 ('highest_leak_two_bin',1992,'total_wings','red','red_leading',30,None),
 ('highest_leak_three_bin',1992,'total_wings','core','red_leading',30,None),
 ('near_zero_leak',1991,'total_wings','core','blue_leading',4,None),
 ('near_zero_leak_common',1991,'continuum_wings','core','common',4,None),
 ('high_leak_large_U',1993,'total_wings','core','common',27,None),
 ('lowest_leak_three_bin',1991,'continuum_wings','blue','red_leading',1,None)]
selected=[]
for label,ep,ss,target,conf,L,comp in examples:
 q=d[(d.epoch==ep)&d.subset.eq(ss)&d.target.eq(target)&d.config.eq(conf)&d.lag_days.eq(L)]
 for bins,v in q.groupby('bins'):
  groups=[('top_U',v[v.kind=='U']),('top_R',v[v.kind=='R']),('top_S',v[v.kind=='S'])]
  if comp:groups.append(('named_component',v[v.component==comp]))
  for sel,vv in groups:
   r=vv.loc[vv.g.idxmax()].copy();r['analysis_type']='same_lag_'+label;r['selection_metric']=sel;selected.append(r)
sel=pd.DataFrame(selected);sel['zero_component_at_selected_lag']=sel.fraction.eq(0);sel=sel.merge(bud,on=keys,how='left')
sel[cols].to_csv(O/'selected_redundancy_leakage.csv',index=False)
pd.concat([a[cols],sel[cols]],ignore_index=True).to_csv(O/'redundancy_leakage.csv',index=False)
print('\nSELECTED CROSSBIN:')
print(sel[['analysis_type','bins','selection_metric','lag_days','component','fraction','g','ell','tuple_count','blue_U_g','blue_involving_S_g']].round(6).to_string(index=False))
