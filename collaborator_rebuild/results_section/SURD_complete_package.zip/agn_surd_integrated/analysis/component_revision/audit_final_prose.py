from pathlib import Path
import pandas as pd
P=Path(__file__).resolve().parents[2]/'data';keys=['epoch','subset','target','config','bins','lag_days']
d=pd.read_csv(P/'individual_components.csv.gz').merge(pd.read_csv(P/'support_and_leakage.csv'),on=keys,validate='many_to_one');d['g']=d.fraction*(1-d.normalized_leakage)
def q(e,ss,t,conf,b,comp):return d[(d.epoch==e)&d.subset.eq(ss)&d.target.eq(t)&d.config.eq(conf)&d.bins.eq(b)&d.component.eq(comp)]
checks=[
(1989,'continuum_wings','blue',2,'S(continuum,red)',16,.193,.267),
(1989,'continuum_wings','blue',3,'S(continuum,red)',17,.091,.223),
(1989,'total_wings','blue',2,'S(blue,red)',6,.163,.220),
(1990,'continuum_wings','core',2,'S(continuum,blue)',12,.150,.399),
(1990,'continuum_wings','core',3,'S(continuum,blue)',13,.085,.221),
(1990,'continuum_wings','core',2,'S(continuum,core)',13,.128,.409),
(1990,'continuum_wings','core',3,'S(continuum,core)',12,.115,.220),
(1990,'continuum_wings','blue',2,'S(continuum,blue)',13,.104,.305),
(1990,'continuum_wings','blue',3,'S(continuum,blue)',12,.224,.263),
(1991,'continuum_wings','core',3,'S(continuum,blue)',15,.061,.190),
(1991,'continuum_wings','core',3,'S(continuum,red)',30,.085,.327),
(1991,'total_wings','blue',2,'S(core,red)',7,.113,.137),
(1991,'total_wings','blue',3,'S(core,red)',24,.113,.329),
(1992,'continuum_wings','core',2,'S(continuum,blue)',7,.121,.239),
(1992,'continuum_wings','core',3,'S(continuum,blue)',17,.052,.382),
(1993,'continuum_wings','core',2,'S(continuum,red)',28,.172,.570),
(1993,'continuum_wings','core',3,'S(continuum,red)',29,.076,.343),
(1993,'total_wings','blue',2,'S(blue,core,red)',24,.063,.843),
(1993,'total_wings','blue',3,'S(blue,core,red)',23,.105,.545)]
err=[]
for e,ss,t,b,comp,L,g,ell in checks:
 x=q(e,ss,t,'common',b,comp);r=x.loc[x.g.idxmax()]
 actual=(int(r.lag_days),round(r.g,3),round(r.normalized_leakage,3));expected=(L,g,ell)
 if actual!=expected:err.append((e,ss,t,b,comp,actual,expected))
print('NAMED_COMMON_S_PROSE',len(checks),'errors',err)
for e,t,comp in [(1989,'blue','U(red)'),(1992,'red','U(blue)')]:
 print('ZERO',e,t,comp,[(ss,b,q(e,ss,t,'common',b,comp).g.max()) for ss in ['total_wings','continuum_wings'] for b in [2,3]])
for conf in ['common','blue_leading','red_leading']:
 print('1992 Ured toblue',conf)
 for ss in ['continuum_wings','total_wings']:
  for b in [2,3]:
   x=q(1992,ss,'blue',conf,b,'U(red)');r=x.loc[x.g.idxmax()];print(ss,b,r[['lag_days','fraction','g','normalized_leakage']].to_dict())
print('FIXED20')
for conf in ['common','blue_leading','red_leading']:
 for comp in ['S(continuum,blue)','S(continuum,red)']:
  r=q(1991,'continuum_wings','core',conf,2,comp).query('lag_days==20').iloc[0];print(conf,comp,r[['fraction','g','normalized_leakage','tuple_count']].to_dict())
for b in [2,3]:
 x=q(1991,'continuum_wings','core','red_leading',b,'S(continuum,red)');r=x.loc[x.fraction.idxmax()];print('1991redleadSFR fmax',b,r[['lag_days','fraction','g','normalized_leakage']].to_dict())
# Named/selected table exact-row validations against source and g extremum
for filename in ['directed_1992_exact.csv','selected_mixed_exact.csv']:
 a=pd.read_csv('tmp/agn_revision/tables/'+filename);errors=[]
 for i,r in a.iterrows():
  x=q(r.epoch,r.subset,r.target,r.config,r.bins,r.component)
  if bool(r.identically_zero):
   if x.g.max()!=0:errors.append((i,'notzero'))
   continue
  v=x.loc[x.g.idxmax()]
  for cc,dd in [('gmax_lag_days','lag_days'),('gmax_g','g'),('gmax_fraction','fraction'),('gmax_normalized_leakage','normalized_leakage')]:
   if abs(r[cc]-v[dd])>1e-12:errors.append((i,cc,r[cc],v[dd]))
 print('SELECTED TABLE',filename,len(a),'errors',errors)
# Check sample of ranks against complete independent atom maxima
rank=pd.read_csv('tmp/agn_revision/rankings/top3_by_g_common.csv')
for e,ss,t,b,fam in [(1989,'total_wings','total',2,'cross_U'),(1992,'continuum_wings','blue',3,'cross_U'),(1991,'continuum_wings','core',2,'S'),(1993,'continuum_wings','core',3,'S'),(1992,'total_wings','blue',3,'R'),(1989,'continuum_wings','core',3,'R')]:
 x=d[(d.epoch==e)&d.subset.eq(ss)&d.target.eq(t)&d.config.eq('common')&d.bins.eq(b)]
 x=x[x.kind.eq('U')&~x.component.eq('U('+t+')')] if fam=='cross_U' else x[x.kind.eq(fam)]
 pk=x.loc[x.groupby('component').g.idxmax()].sort_values(['g','component'],ascending=[False,True]).head(3)
 rr=rank[(rank.epoch==e)&rank.subset.eq(ss)&rank.target.eq(t)&rank.bins.eq(b)&rank.family.eq(fam)].sort_values('rank')
 print('RANK CASE',e,ss,t,b,fam,'correct',pk.component.tolist()==rr.component.tolist())
