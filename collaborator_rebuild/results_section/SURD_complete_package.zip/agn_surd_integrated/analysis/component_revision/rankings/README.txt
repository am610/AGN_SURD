Rank exact named SURD atoms; no new probability estimation or significance tests.

Usage (from any directory):
    python rank_components.py [--data-dir /path/to/data] [--out-dir /path/to/output]

The default data path is resolved relative to this script's workspace root.
Each named atom is first maximized over the 30 base lags, then ranked within
U, cross-U, R or S. Hence a top-three list may contain three different lags.
Separate snapshots rank atoms at one shared lag to avoid that ambiguity.
Strictly zero atom curves have no preferred peak lag or corresponding leakage.
Exact numerical ties choose shortest lag, then lexicographic component name.
All rankings are descriptive; zero-valued ranks are retained and flagged.

Primary outputs: all_atom_extrema.csv; top3_by_g_all_configurations.csv; top3_by_f_all_configurations.csv; common_top3_{cross_U,R,S}.csv; same_lag_all_components.csv; same_lag_top3_per_family.csv. U includes self-history; cross_U excludes it. For atom maxima use gmax_ or fmax_ fields consistently. Component labels preserve source names (core is the core line).
