"""Build common/mixed named-component table panels from ranked CSVs.

Run after rank_components.py. No absolute filesystem paths are embedded.
Each cell contains up to three nonzero distinct atoms at their own g maxima;
these independently selected values must never be summed across the cell.
"""
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'tables'
SYMBOL={'continuum':'F','total':'H','blue':'B','core':'C','red':'R'}
TARGETS={'total_wings':['total','blue','core','red'],'continuum_wings':['continuum','blue','core','red']}
SET={'total_wings':r'total set $(H,B,C,R)$','continuum_wings':r'F5100 set $(F,B,C,R)$'}
FAMILIES=[('cross_U','cross_u','unique cross-series'),('R','redundant','redundant'),('S','synergistic','synergistic')]
CONFIGS=[('common','common lags'),('blue_leading',r'the blue predictor shifted 5~d further back'),('red_leading',r'the red predictor shifted 5~d further back')]


def atom(s):
    kind,members=s[:-1].split('(')
    return kind+'('+','.join(SYMBOL[x] for x in members.split(','))+')'


def cell(q):
    q=q[q.positive_peak].sort_values('rank')
    if q.empty:return r'$\text{---}$'
    lines=[]
    for _,r in q.iterrows():
        # Keep three decimals; distinguish small positive values from exact zeros.
        fmt=lambda x:r'{<}0.001' if 0<x<.0005 else f'{x:.3f}'
        text=atom(r.component)+':'+fmt(r.gmax_fraction)+'/'+fmt(r.gmax_g)+'/'+fmt(r.gmax_normalized_leakage)+r'\;('+str(int(r.gmax_lag_days))+')'
        lines.append('$'+text+'$')
    return r'\shortstack[l]{'+r' \\ '.join(lines)+'}'


def main():
    OUT.mkdir(exist_ok=True)
    d=pd.read_csv(ROOT/'top3_by_g_all_configurations.csv')
    for config,config_label in CONFIGS:
        for family,slug,description in FAMILIES:
            for subset,targets in TARGETS.items():
                q=d[d.family.eq(family)&d.subset.eq(subset)&d.config.eq(config)].copy()
                suffix='' if config=='common' else '_'+config
                stem=slug+'_'+subset+suffix
                q.to_csv(OUT/f'{stem}_exact.csv',index=False)
                first=(stem=='cross_u_total_wings')
                caption=(f'Ranked {description} components for the '+SET[subset]+' with '+config_label+'. ')
                if first:
                    caption+=(r'Each cell lists up to three distinct nonzero atoms in descending order of their own maximum $g_a=I_a/H(Y)$ over 1--30~d. '+
                        r'Entries are $a:f_a/g_a/\ell\;(L)$, where $f_a=I_a/I(Y;\mathbf X)$ and leakage is evaluated at the same base lag $L$ in days. '+
                        r'Different entries can have different lags and must not be added. '+
                        r'$F,H,B,C,R$ denote continuum, total, blue, core and red fluxes; parentheses identify predictors, and the target is listed separately. '+
                        r'Self-history is excluded. A dash means all eligible atoms are zero throughout the scan; smaller positive values that round to zero are printed as $<0.001$. Rankings are descriptive, without a significance threshold or uncertainty estimate.')
                elif config=='common':
                    caption+=(r'Notation and independent peak selection follow Table~\ref{tab:cross_u_total_wings}. '+
                        (r'Self-history is excluded. ' if family=='cross_U' else '')+
                        r'The three entries in a cell need not share a lag and must not be added. No significance threshold is applied.')
                else:
                    caption+=(r"Entries are $a:f_a/g_a/\ell\;(L)$ at each named atom's own maximum $g_a=I_a/H(Y)$, ranked within the indicated category. "+
                        r'Here $f_a=I_a/I(Y;\mathbf X)$ and $\ell$ is simultaneous leakage; distinct entries may have different base lags and must not be added. '+
                        (r'Self-history is excluded. ' if family=='cross_U' else '')+
                        r'Zero atoms are omitted; a dash denotes no nonzero atom. Values below rounding resolution are printed as $<0.001$. These are descriptive rankings, without significance tests.')
                write_panel(stem,caption,q,targets)

    # The separate self-history appendix keeps memory out of the cross-U tables.
    peaks=pd.read_csv(ROOT/'all_atom_extrema.csv')
    for subset,targets in TARGETS.items():
        q=peaks[peaks.config.eq('common')&peaks.subset.eq(subset)&peaks.is_self].copy()
        q['positive_peak']=q.gmax_defined;q['rank']=1
        stem='self_unique_'+subset
        q.to_csv(OUT/f'{stem}_exact.csv',index=False)
        caption=(r'Unique self-history for the '+SET[subset]+
                 r' with common lags. Entries are $U(j):f/g/\ell\;(L)$ at the maximum $g=U(j)/H(Y)$ over 1--30~d, with simultaneous leakage. The source $j$ equals the target. These memory terms are excluded from the cross-series tables. Values are descriptive, with no uncertainty or significance estimate.')
        write_panel(stem,caption,q,targets)
    (OUT/'README.txt').write_text('Eighteen full-width panels: cross_u, redundant, synergistic x total_wings/continuum_wings x common/blue_leading/red_leading. Each has20epoch-targetrows and2/3bincells. Common filenames have no configuration suffix. Two additional common-lag self_unique appendixpanels. Sourceexactrows are companion CSVs. Requires booktabs and amsmath; core=C. Parenthetical atom notation U(F),S(F,R),R(H,B,C,R). All values are own-atom maxima of g, so not simultaneous acrossentries. Scripts use only relative paths.\n')
    print('Generated eighteen ranked panels plus two self-history panels, each with exact CSV.')


def write_panel(stem,caption,q,targets):
    rows=[]
    for epoch in range(1989,1994):
        for i,target in enumerate(targets):
            qq=q[q.epoch.eq(epoch)&q.target.eq(target)]
            rows.append((str(epoch) if i==0 else '')+' & $'+SYMBOL[target]+'$ & '+cell(qq[qq.bins.eq(2)])+' & '+cell(qq[qq.bins.eq(3)])+r' \\')
        if epoch!=1993:rows.append(r'\addlinespace[3pt]')
    text='\n'.join([
        r'\begin{table*}[p]',r'\centering',r'\scriptsize',
        r'\caption{'+caption+'}',r'\label{tab:'+stem+'}',
        r'\setlength{\tabcolsep}{5pt}',r'\renewcommand{\arraystretch}{1.15}',
        r'\begin{tabular}{ccp{0.39\textwidth}p{0.39\textwidth}}',r'\toprule',
        r'Epoch & Target & Two bins: $a:f_a/g_a/\ell\;(L)$ & Three bins: $a:f_a/g_a/\ell\;(L)$ \\',
        r'\midrule',*rows,r'\bottomrule',r'\end{tabular}',r'\end{table*}',''])
    (OUT/f'{stem}.tex').write_text(text)


if __name__=='__main__':main()
