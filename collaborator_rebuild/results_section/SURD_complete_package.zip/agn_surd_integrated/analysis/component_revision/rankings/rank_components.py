"""Rank exact named SURD atoms; no new probability estimation or significance tests.

Usage (from any directory):
    python rank_components.py [--data-dir /path/to/data] [--out-dir /path/to/output]

The default data path is resolved relative to this script's workspace root.
Each named atom is first maximized over the 30 base lags, then ranked within
U, cross-U, R or S. Hence a top-three list may contain three different lags.
Separate snapshots rank atoms at one shared lag to avoid that ambiguity.
Strictly zero atom curves have no preferred peak lag or corresponding leakage.
Exact numerical ties choose shortest lag, then lexicographic component name.
All rankings are descriptive; zero-valued ranks are retained and flagged.
"""
from pathlib import Path
import argparse
import hashlib
import json
import pandas as pd
import numpy as np

SCAN = ['epoch','subset','target','config','bins']
KEY = SCAN + ['lag_days']
ATOM = SCAN + ['kind','component']
FAMILIES = ['U','cross_U','R','S']


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def family_rows(df, family):
    if family == 'cross_U':
        return df[df.kind.eq('U') & ~df.is_self]
    return df[df.kind.eq(family)]


def atom_peaks(d, metric, prefix):
    q = d.sort_values([metric,'lag_days'], ascending=[False,True], kind='stable').drop_duplicates(ATOM)
    # Record near-ties for audit; selection itself uses exact numerical order.
    mx=d.groupby(ATOM)[metric].transform('max')
    ties=d.assign(tie=np.isclose(d[metric],mx,rtol=0,atol=1e-12)).groupby(ATOM).tie.sum().rename(prefix+'_near_tie_count').reset_index()
    cols=['lag_days','fraction','g','bits','normalized_leakage','tuple_count','joint_mi_bits']
    q=q[ATOM+cols+['is_self']].rename(columns={x:prefix+'_'+x for x in cols})
    q=q.merge(ties,on=ATOM,validate='one_to_one')
    q[prefix+'_defined']=q[prefix+'_'+metric]>0
    q.loc[~q[prefix+'_defined'],[prefix+'_lag_days',prefix+'_normalized_leakage',prefix+'_tuple_count',prefix+'_joint_mi_bits']]=np.nan
    return q


def rank_peaks(peaks, metric, prefix):
    records=[]
    for family in FAMILIES:
        q=family_rows(peaks,family).copy()
        q['family']=family
        q=q.sort_values(SCAN+[prefix+'_'+metric,'component'],ascending=[True]*len(SCAN)+[False,True],kind='stable')
        q['rank']=q.groupby(SCAN).cumcount()+1
        q['positive_peak']=q[prefix+'_'+metric]>0
        records.append(q)
    return pd.concat(records,ignore_index=True)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data-dir',type=Path,default=Path(__file__).resolve().parents[3]/'data')
    ap.add_argument('--out-dir',type=Path,default=Path(__file__).resolve().parent)
    args=ap.parse_args(); args.out_dir.mkdir(parents=True,exist_ok=True)
    out=args.out_dir; source=args.data_dir
    a=pd.read_csv(source/'individual_components.csv.gz')
    s=pd.read_csv(source/'support_and_leakage.csv')
    if 'normalized_value' in a and 'fraction' not in a:a=a.rename(columns={'normalized_value':'fraction'})
    assert len(a)==187200 and len(s)==7200
    assert not a.duplicated(ATOM+['lag_days']).any()
    d=a.merge(s,on=KEY,validate='many_to_one')
    d['g']=d.fraction*(1-d.normalized_leakage)
    d['is_self']=d.component.eq('U('+d.target+')')
    gp=atom_peaks(d,'g','gmax');fp=atom_peaks(d,'fraction','fmax')
    peaks=gp.merge(fp.drop(columns='is_self'),on=ATOM,validate='one_to_one')
    peaks['identically_zero']=~peaks.gmax_defined
    assert len(peaks)==6240
    peaks.to_csv(out/'all_atom_extrema.csv',index=False)

    rg=rank_peaks(peaks,'g','gmax');rf=rank_peaks(peaks,'fraction','fmax')
    rg.to_csv(out/'all_atom_rankings_by_g.csv',index=False)
    rf.to_csv(out/'all_atom_rankings_by_f.csv',index=False)
    topg=rg[rg['rank']<=3].copy();topf=rf[rf['rank']<=3].copy()
    for name,data in [('top3_by_g',topg),('top3_by_f',topf)]:
        data.to_csv(out/(name+'_all_configurations.csv'),index=False)
        data[data.config.eq('common')].to_csv(out/(name+'_common.csv'),index=False)
        data[~data.config.eq('common')].to_csv(out/(name+'_mixed.csv'),index=False)
    for family in FAMILIES:
        topg[topg.family.eq(family)&topg.config.eq('common')].to_csv(out/('common_top3_'+family+'.csv'),index=False)

    # Explicit one-lag snapshots. Multiple reasons selecting the same lag are combined.
    anchors=[]
    for _,scan in d.groupby(SCAN,sort=True):
        identity=scan.iloc[0][SCAN].to_dict()
        cand={'one_day':1}
        sup=scan.drop_duplicates('lag_days').sort_values('lag_days')
        cand['minimum_leakage']=int(sup.loc[sup.normalized_leakage.idxmin(),'lag_days'])
        cand['maximum_leakage']=int(sup.loc[sup.normalized_leakage.idxmax(),'lag_days'])
        cand['largest_individual_g']=int(scan.sort_values(['g','lag_days','component'],ascending=[False,True,True]).iloc[0].lag_days)
        for family in ['cross_U','R','S']:
            z=family_rows(scan,family).sort_values(['g','lag_days','component'],ascending=[False,True,True])
            if len(z) and z.iloc[0].g>0:cand['largest_'+family+'_g']=int(z.iloc[0].lag_days)
        for lag in sorted(set(cand.values())):
            anchors.append({**identity,'lag_days':lag,'anchor_reason':';'.join(k for k,v in cand.items() if v==lag)})
    anchors=pd.DataFrame(anchors);anchors.to_csv(out/'informative_anchor_lags.csv',index=False)
    snap=anchors.merge(d,on=KEY,validate='one_to_many')
    snap.to_csv(out/'same_lag_all_components.csv',index=False)
    sr=[]
    for family in FAMILIES:
        q=family_rows(snap,family).copy();q['family']=family
        q=q.sort_values(KEY+['g','component'],ascending=[True]*len(KEY)+[False,True])
        q['rank']=q.groupby(KEY).cumcount()+1
        sr.append(q[q['rank']<=3])
    snaprank=pd.concat(sr,ignore_index=True)
    snaprank['positive_value']=snaprank.g>0
    snaprank.to_csv(out/'same_lag_top3_per_family.csv',index=False)

    # Positive atoms that recur in the top three for both bin choices.
    bk=['epoch','subset','target','config','family','component']
    z=topg[topg.positive_peak]
    cols=['rank','gmax_lag_days','gmax_fraction','gmax_g','gmax_normalized_leakage']
    recur=z[z.bins.eq(2)][bk+cols].merge(z[z.bins.eq(3)][bk+cols],on=bk,suffixes=('_2bins','_3bins'),validate='one_to_one')
    recur.to_csv(out/'recurring_top3_both_bins.csv',index=False)
    br=[]
    for identity,q in topg.groupby(['epoch','subset','target','config','family']):
        sets=[set(q[q.bins.eq(b)&q.positive_peak].component) for b in [2,3]]
        winners=[]
        for b in [2,3]:
            v=q[q.bins.eq(b)&q['rank'].eq(1)].iloc[0]
            winners.append(v.component if v.positive_peak else '')
        br.append(dict(zip(['epoch','subset','target','config','family'],identity))|{
            'positive_count_2bins':len(sets[0]),'positive_count_3bins':len(sets[1]),
            'top3_overlap_count':len(sets[0]&sets[1]),'top3_union_count':len(sets[0]|sets[1]),
            'top1_2bins':winners[0],'top1_3bins':winners[1],
            'same_positive_top1':bool(winners[0]) and winners[0]==winners[1],
            'recurring_components':';'.join(sorted(sets[0]&sets[1]))})
    pd.DataFrame(br).to_csv(out/'bin_rank_agreement.csv',index=False)

    # Changes in the leading identity and top-three membership under each lag shift.
    changes=[]
    ck=['epoch','subset','target','bins','family']
    for identity,q in topg.groupby(ck):
        base=q[q.config.eq('common')];basewin=base[base['rank'].eq(1)].iloc[0]
        basetop=set(base[base.positive_peak].component)
        for config in ['blue_leading','red_leading']:
            z=q[q.config.eq(config)];win=z[z['rank'].eq(1)].iloc[0]
            newtop=set(z[z.positive_peak].component)
            rec=dict(zip(ck,identity))|{'config':config,'common_top1':basewin.component if basewin.positive_peak else '',
                'mixed_top1':win.component if win.positive_peak else '',
                'same_positive_top1':bool(basewin.positive_peak and win.positive_peak and basewin.component==win.component),
                'top3_overlap_count':len(basetop&newtop),'shared_positive_components':';'.join(sorted(basetop&newtop))}
            for pref,r in [('common',basewin),('mixed',win)]:
                for field in ['gmax_lag_days','gmax_fraction','gmax_normalized_leakage','gmax_g']:
                    rec[pref+'_'+field]=r[field]
            changes.append(rec)
    pd.DataFrame(changes).to_csv(out/'mixed_rank_changes.csv',index=False)

    manifest={
        'sources':{n:sha(source/n) for n in ['individual_components.csv.gz','support_and_leakage.csv']},
        'script_sha256':sha(__file__),'scan_count':240,'all_atom_extrema':len(peaks),
        'top3_rows_each_metric_including_cross_U':len(topg),
        'anchor_scan_lag_pairs':len(anchors),'same_lag_atom_rows':len(snap),
        'zero_atom_curves':int(peaks.identically_zero.sum()),
        'ranking_rule':'First maximize each exact named atom across lag; rank distinct atoms within each family by its maximum. Select exact ties by shortest lag, then lexicographic component name.',
        'zero_rule':'All-zero curves have no selected peak lag or simultaneous leakage. Zero ranks remain in top-three CSVs with positive_peak=false.',
        'uncertainty':'No statistical detection threshold or significance test is applied.',
        'snapshot_rule':'At each informative anchor lag rank exact distinct atoms within family; all26 components also supplied.'}
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (out/'README.txt').write_text(__doc__+'\nPrimary outputs: all_atom_extrema.csv; top3_by_g_all_configurations.csv; top3_by_f_all_configurations.csv; common_top3_{cross_U,R,S}.csv; same_lag_all_components.csv; same_lag_top3_per_family.csv. U includes self-history; cross_U excludes it. For atom maxima use gmax_ or fmax_ fields consistently. Component labels preserve source names (core is the core line).\n')
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':main()
