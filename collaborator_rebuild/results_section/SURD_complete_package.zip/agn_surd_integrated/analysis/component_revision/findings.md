# Redundancy and leakage audit for revision

All numbers are recomputed from the archived component and support/leakage CSVs in output/agn_surd_integrated/data. The estimator was not rerun. f=component/joint MI; g=component/target entropy=(1−ell)f. Every reported leakage and tuple count belongs to the same lag as its component. Lag is base lag in observed days. Original names: F continuum, H total line, B blue wing, C core, R red wing; R(...) denotes redundancy, not a red-to-target causal arrow.

## Coverage

redundancy_leakage.csv contains 3940 records: each of 240 scans has the three pair atoms R(B,C), R(B,R), R(C,R) maximized separately by f and g; the largest redundancy group of size >=3 maximized by each metric; four simultaneous top-family components at each minimum/maximum leakage; and selected fixed-lag cross-bin examples. A zero-component flag identifies artificial argmax ties. Source-specific U, sum of source-containing S, and source-containing R budgets accompany each record. Inclusive pair redundancies sum all R atoms containing a fixed pair, including groups of size3/4. These overlapping source or pair sums must not be added across sources or pairs.

## Largest pair atoms by subset and bin count

These are maximized over epochs, targets, configurations and lag, within the stated subset/bin. They are empirical magnitudes, not significance claims.

| subset | component | bins | epoch | target | config | lag_days | fraction | g | ell | tuple_count |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| continuum_wings | R(blue,core) | 2 | 1989 | core | red_leading | 1 | 0.336946 | 0.319414 | 0.052032 | 172 |
| continuum_wings | R(blue,core) | 3 | 1991 | core | blue_leading | 1 | 0.423098 | 0.404042 | 0.045040 | 184 |
| continuum_wings | R(blue,red) | 2 | 1991 | continuum | common | 30 | 0.241003 | 0.070541 | 0.707302 | 153 |
| continuum_wings | R(blue,red) | 3 | 1990 | blue | common | 8 | 0.079327 | 0.060016 | 0.243442 | 209 |
| continuum_wings | R(core,red) | 2 | 1990 | red | blue_leading | 2 | 0.397854 | 0.354069 | 0.110053 | 212 |
| continuum_wings | R(core,red) | 3 | 1992 | core | blue_leading | 1 | 0.319538 | 0.301019 | 0.057955 | 233 |
| total_wings | R(blue,core) | 2 | 1991 | blue | blue_leading | 28 | 0.181920 | 0.060681 | 0.666443 | 118 |
| total_wings | R(blue,core) | 3 | 1993 | total | common | 24 | 0.105143 | 0.047327 | 0.549882 | 235 |
| total_wings | R(blue,red) | 2 | 1993 | red | blue_leading | 11 | 0.199188 | 0.045675 | 0.770694 | 243 |
| total_wings | R(blue,red) | 3 | 1993 | core | red_leading | 30 | 0.107448 | 0.040326 | 0.624691 | 227 |
| total_wings | R(core,red) | 2 | 1991 | blue | blue_leading | 7 | 0.121398 | 0.107509 | 0.114406 | 160 |
| total_wings | R(core,red) | 3 | 1990 | core | common | 9 | 0.042919 | 0.027521 | 0.358782 | 206 |

The pair-only R(B,R) atoms are markedly smaller than the strongest R(B,C) or R(C,R) atoms in the F5100 set. This does NOT mean blue/red information is unshared: higher-order groups can carry their shared information. In the 1990 blue target, common lag8d, N=209, the two-bin pair atom R(B,R) is zero but the sum of all redundancy atoms containing both B and R is g=0.415320. With three bins at the same lag, the pair atom is g=0.060016 and the inclusive sum is g=0.446210. In the total set, the maximum pair-only atoms are generally smaller because much shared information is allocated to groups also containing H.

## Matched cross-bin examples at exactly the same lag

| analysis_type | bins | lag_days | component | fraction | g | ell | tuple_count |
| --- | --- | --- | --- | --- | --- | --- | --- |
| same_lag_R_BC_stable | 2 | 1 | R(blue,core) | 0.336946 | 0.319414 | 0.052032 | 172 |
| same_lag_R_BC_stable | 3 | 1 | R(blue,core) | 0.413400 | 0.380840 | 0.078762 | 172 |
| same_lag_R_CR_shifted | 2 | 2 | R(core,red) | 0.349155 | 0.312769 | 0.104211 | 231 |
| same_lag_R_CR_shifted | 3 | 2 | R(core,red) | 0.319971 | 0.281745 | 0.119466 | 231 |
| same_lag_R_CR_other_epoch | 2 | 5 | R(core,red) | 0.417202 | 0.336470 | 0.193510 | 203 |
| same_lag_R_CR_other_epoch | 3 | 5 | R(core,red) | 0.241290 | 0.216803 | 0.101482 | 203 |
| same_lag_R_BR_small | 2 | 8 | R(blue,red) | 0.000000 | 0.000000 | 0.204283 | 209 |
| same_lag_R_BR_small | 3 | 8 | R(blue,red) | 0.079327 | 0.060016 | 0.243442 | 209 |
| same_lag_fourway_1992 | 2 | 2 | R(total,blue,core,red) | 0.757108 | 0.681498 | 0.099868 | 241 |
| same_lag_fourway_1992 | 3 | 2 | R(total,blue,core,red) | 0.718727 | 0.672915 | 0.063740 | 241 |
| same_lag_threeway_1991 | 2 | 4 | R(blue,core,red) | 0.559482 | 0.515432 | 0.078734 | 194 |
| same_lag_threeway_1991 | 3 | 4 | R(blue,core,red) | 0.121084 | 0.112158 | 0.073715 | 194 |

The strongest cross-bin-stable R(B,C) example is the 1989 core, F5100 set, red-leading,L1: g=.319414/.380840 (two/three bins), ell=.052032/.078762,N172. The 1992 core blue-leading R(C,R) example gives g=.312769/.281745 at L2,N231; the three-bin maximum is slightly earlier at L1,g=.301019,N233. Both are strong shared-information contributions, not evidence that one emitting region causes another.

The 1991 blue target's common-lag R(B,C,R) at L4 changes from g=.515432 to .112158, while R(B,C) becomes the largest redundancy in the three-bin result. Thus the broad conclusion of shared line information can persist when its assignment between pair and triple groups changes markedly.

For the 1992 total-set blue target, the four-way redundancy at the same L2 is g=.681498/.672915 with ell=.099868/.063740,N241. Its three-bin maximum occurs at L3,g=.709007,ell=.076369,N239. This example separates robust high shared information from a small shift of the maximizing lag.

## Redundancy does not certify a removable predictor

The following columns are simultaneous diagnostics. U_i+sum(S involving i) is NOT interpreted as the exact deletion loss for the four-source decomposition.

| analysis_type | bins | lag_days | component | g | ell | tuple_count | blue_U_g | blue_involving_S_g | core_U_g | core_involving_S_g | red_U_g | red_involving_S_g |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| same_lag_R_BC_stable | 2 | 1 | R(blue,core) | 0.319414 | 0.052032 | 172 | 0.000000 | 0.045128 | 0.150823 | 0.074385 | 0.000000 | 0.019563 |
| same_lag_R_BC_stable | 3 | 1 | R(blue,core) | 0.380840 | 0.078762 | 172 | 0.000000 | 0.098204 | 0.053885 | 0.124769 | 0.000000 | 0.052605 |
| same_lag_R_CR_other_epoch | 2 | 5 | R(core,red) | 0.336470 | 0.193510 | 203 | 0.000000 | 0.094158 | 0.044102 | 0.115569 | 0.002395 | 0.138757 |
| same_lag_R_CR_other_epoch | 3 | 5 | R(core,red) | 0.216803 | 0.101482 | 203 | 0.000000 | 0.129101 | 0.016091 | 0.147509 | 0.003721 | 0.123355 |
| same_lag_omission_candidate_local | 2 | 1 | R(blue,core) | 0.138390 | 0.017691 | 184 | 0.000000 | 9.529e-15 | 0.305565 | 0.025253 | 0.000000 | 0.014661 |
| same_lag_omission_candidate_local | 3 | 1 | R(blue,core) | 0.404042 | 0.045040 | 184 | 0.005042 | 0.035595 | 0.079259 | 0.057986 | 0.000000 | 0.036401 |
| same_lag_omission_candidate_later | 2 | 20 | R(blue,core) | 0.000000 | 0.099639 | 121 | 0.000000 | 0.183012 | 0.076963 | 0.096993 | 0.000000 | 0.213744 |
| same_lag_omission_candidate_later | 3 | 20 | R(blue,core) | 0.105948 | 0.281884 | 121 | 0.003347 | 0.073789 | 0.013544 | 0.195852 | 0.000000 | 0.222736 |

At the 1990 core, F5100 set, blue-leading,L5,N203, R(C,R) accounts for g=.336470/.216803. Nevertheless, the red predictor participates in synergistic sums .138757/.123355 and also has unique fractions on the target-entropy scale .002395/.003721. The core has unique .044102/.016091 and synergistic sums .115569/.147509. Large pair redundancy therefore coexists with information not represented by that pair atom alone.

A limited candidate for omission assessment is B for the 1991 core,F5100 set,blue-leading,L1,N184: in two bins U(B)=0 and the sum of B-containing synergy is about9.5e-15; its information is allocated redundantly. But at the same point with three bins U(B)/H=.005042 and summed B-synergy=.035595; at L20 in two bins the summed B-synergy is .183012. Thus even this candidate is local and discretization-dependent, not grounds to remove B from the complete lag study.

The proper same-sample omission criterion is

Delta ell_i = [H(Y|X_without_i)−H(Y|X_all)]/H(Y) = I(Y;X_i|X_without_i)/H(Y).

A negligible value could support omitting that predictor for the specified target, history and resolution. The four-source U/R/S atoms do not in general determine the reduced-set MI, so no deletion loss is claimed here. A reduced joint distribution with unchanged target samples/bin edges, or retained subset MI, is needed. No raw histogram or reduced-set estimator run has been introduced. Also, H≈B+C+R in unbinned fluxes does not imply that the binned H label is determined by the three component-bin labels.

## Leakage extrema paired with simultaneous U and S

| analysis_type | epoch | subset | target | config | bins | lag_days | component | fraction | g | ell | tuple_count |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| same_lag_highest_leak_two_bin | 1992 | total_wings | red | red_leading | 2 | 30 | U(red) | 0.000918 | 0.000030 | 0.967066 | 205 |
| same_lag_highest_leak_two_bin | 1992 | total_wings | red | red_leading | 2 | 30 | S(blue,red) | 0.291019 | 0.009584 | 0.967066 | 205 |
| same_lag_highest_leak_two_bin | 1992 | total_wings | red | red_leading | 3 | 30 | U(core) | 0.039962 | 0.008130 | 0.796567 | 205 |
| same_lag_highest_leak_two_bin | 1992 | total_wings | red | red_leading | 3 | 30 | S(total,blue) | 0.105086 | 0.021378 | 0.796567 | 205 |
| same_lag_highest_leak_three_bin | 1992 | total_wings | core | red_leading | 2 | 30 | U(red) | 0.006649 | 0.000462 | 0.930487 | 205 |
| same_lag_highest_leak_three_bin | 1992 | total_wings | core | red_leading | 2 | 30 | S(total,core,red) | 0.230372 | 0.016014 | 0.930487 | 205 |
| same_lag_highest_leak_three_bin | 1992 | total_wings | core | red_leading | 3 | 30 | U(core) | 0.060852 | 0.011481 | 0.811338 | 205 |
| same_lag_highest_leak_three_bin | 1992 | total_wings | core | red_leading | 3 | 30 | S(total,blue,core,red) | 0.115753 | 0.021838 | 0.811338 | 205 |
| same_lag_near_zero_leak_common | 1991 | continuum_wings | core | common | 2 | 4 | U(core) | 0.140087 | 0.140087 | 3.159e-14 | 194 |
| same_lag_near_zero_leak_common | 1991 | continuum_wings | core | common | 2 | 4 | S(core,red) | 0.059454 | 0.059454 | 3.159e-14 | 194 |
| same_lag_near_zero_leak_common | 1991 | continuum_wings | core | common | 3 | 4 | U(blue) | 0.101351 | 0.093325 | 0.079187 | 194 |
| same_lag_near_zero_leak_common | 1991 | continuum_wings | core | common | 3 | 4 | S(blue,core) | 0.028719 | 0.026445 | 0.079187 | 194 |
| same_lag_high_leak_large_U | 1993 | total_wings | core | common | 2 | 27 | U(red) | 0.632408 | 0.128139 | 0.797379 | 232 |
| same_lag_high_leak_large_U | 1993 | total_wings | core | common | 2 | 27 | S(blue,red) | 0.103009 | 0.020872 | 0.797379 | 232 |
| same_lag_high_leak_large_U | 1993 | total_wings | core | common | 3 | 27 | U(red) | 0.064466 | 0.031154 | 0.516736 | 232 |
| same_lag_high_leak_large_U | 1993 | total_wings | core | common | 3 | 27 | S(total,red) | 0.117139 | 0.056609 | 0.516736 | 232 |

Highest two-bin leakage occurs for the 1992 red target,total set,red-leading,L30,N205: ell=.967066, so the total explained fraction is only .032934. The leading synergy S(B,R) has f=.291019 but g=.009584; top U(R) is only g=.000030. At that identical point with three bins ell=.796567 and the leading synergy switches to S(H,B),f=.105086,g=.021378. The largest three-bin leakage anywhere occurs for the 1992 core,total set,red-leading,L30,N205: ell=.811338; top S(H,B,C,R) has f=.115753,g=.021838.

A large relative unique contribution at high leakage occurs for the 1993 core,total set,common,L27,N232: U(R) has f=.632408,ell=.797379,g=.128139. At the same point with three bins U(R) has f=.064466,ell=.516736,g=.031154. The difference is allocation sensitivity, not a demonstrated change in physical causality.

Near-zero leakage: 1991 core,F5100 set,common,L4,N194 has ell≈3.16e-14 with two bins, U(C)=.140087,R(B,C,R)=.457864 and largest S(C,R)=.059454 (f and g coincide). With three bins at exactly the same point ell=.079187; top U(B) has f=.101351,g=.093325, and top S(B,C) f=.028719,g=.026445. Occupied coarse histogram cells determine the observed discrete target in the binary sample; this does not establish absence of unobserved physical drivers.

All additional per-target and per-configuration extrema, including low-leakage top-R and cross-U components, are in redundancy_leakage.csv. Fixed-lag examples are separately in selected_redundancy_leakage.csv; all360 paired two/three-bin pair-maxima comparisons are in redundancy_pair_crossbin.csv.
