from pathlib import Path
import pandas as pd, numpy as np
P=Path(__file__).resolve().parent;a=pd.read_csv(P/'redundancy_leakage.csv')
def md(frame):
 def fmt(x):
  if isinstance(x,(float,np.floating)): return f'{x:.6f}' if abs(x)>1e-10 or x==0 else f'{x:.3e}'
  return str(x)
 return '| '+' | '.join(frame.columns)+' |\n| '+' | '.join(['---']*len(frame.columns))+' |\n'+'\n'.join('| '+' | '.join(fmt(v) for v in row)+' |' for row in frame.itertuples(index=False,name=None))+'\n'
pp=a[a.analysis_type.eq('pair_peak')&a.selection_metric.eq('g')]
maximum=pp.loc[pp.groupby(['subset','component','bins']).g.idxmax(),['subset','component','bins','epoch','target','config','lag_days','fraction','g','ell','tuple_count']]
sel=a[a.analysis_type.str.startswith('same_lag_')]
chosen=sel[sel.analysis_type.isin(['same_lag_R_BC_stable','same_lag_R_CR_shifted','same_lag_R_CR_other_epoch','same_lag_R_BR_small','same_lag_fourway_1992','same_lag_threeway_1991'])&sel.selection_metric.eq('named_component')][['analysis_type','bins','lag_days','component','fraction','g','ell','tuple_count']]
omit=sel[sel.analysis_type.isin(['same_lag_R_CR_other_epoch','same_lag_R_BC_stable','same_lag_omission_candidate_local','same_lag_omission_candidate_later'])&sel.selection_metric.eq('named_component')][['analysis_type','bins','lag_days','component','g','ell','tuple_count','blue_U_g','blue_involving_S_g','core_U_g','core_involving_S_g','red_U_g','red_involving_S_g']]
leak=sel[sel.analysis_type.isin(['same_lag_highest_leak_two_bin','same_lag_highest_leak_three_bin','same_lag_near_zero_leak_common','same_lag_high_leak_large_U'])&sel.selection_metric.isin(['top_U','top_S'])][['analysis_type','epoch','subset','target','config','bins','lag_days','component','fraction','g','ell','tuple_count']]
text='''# Redundancy and leakage audit for revision

All numbers are recomputed from the archived component and support/leakage CSVs in output/agn_surd_integrated/data. The estimator was not rerun. f=component/joint MI; g=component/target entropy=(1−ell)f. Every reported leakage and tuple count belongs to the same lag as its component. Lag is base lag in observed days. Original names: F continuum, H total line, B blue wing, C core, R red wing; R(...) denotes redundancy, not a red-to-target causal arrow.

## Coverage

redundancy_leakage.csv contains 3940 records: each of 240 scans has the three pair atoms R(B,C), R(B,R), R(C,R) maximized separately by f and g; the largest redundancy group of size >=3 maximized by each metric; four simultaneous top-family components at each minimum/maximum leakage; and selected fixed-lag cross-bin examples. A zero-component flag identifies artificial argmax ties. Source-specific U, sum of source-containing S, and source-containing R budgets accompany each record. Inclusive pair redundancies sum all R atoms containing a fixed pair, including groups of size3/4. These overlapping source or pair sums must not be added across sources or pairs.

## Largest pair atoms by subset and bin count

These are maximized over epochs, targets, configurations and lag, within the stated subset/bin. They are empirical magnitudes, not significance claims.

'''+md(maximum)+'''
The pair-only R(B,R) atoms are markedly smaller than the strongest R(B,C) or R(C,R) atoms in the F5100 set. This does NOT mean blue/red information is unshared: higher-order groups can carry their shared information. In the 1990 blue target, common lag8d, N=209, the two-bin pair atom R(B,R) is zero but the sum of all redundancy atoms containing both B and R is g=0.415320. With three bins at the same lag, the pair atom is g=0.060016 and the inclusive sum is g=0.446210. In the total set, the maximum pair-only atoms are generally smaller because much shared information is allocated to groups also containing H.

## Matched cross-bin examples at exactly the same lag

'''+md(chosen)+'''
The strongest cross-bin-stable R(B,C) example is the 1989 core, F5100 set, red-leading,L1: g=.319414/.380840 (two/three bins), ell=.052032/.078762,N172. The 1992 core blue-leading R(C,R) example gives g=.312769/.281745 at L2,N231; the three-bin maximum is slightly earlier at L1,g=.301019,N233. Both are strong shared-information contributions, not evidence that one emitting region causes another.

The 1991 blue target's common-lag R(B,C,R) at L4 changes from g=.515432 to .112158, while R(B,C) becomes the largest redundancy in the three-bin result. Thus the broad conclusion of shared line information can persist when its assignment between pair and triple groups changes markedly.

For the 1992 total-set blue target, the four-way redundancy at the same L2 is g=.681498/.672915 with ell=.099868/.063740,N241. Its three-bin maximum occurs at L3,g=.709007,ell=.076369,N239. This example separates robust high shared information from a small shift of the maximizing lag.

## Redundancy does not certify a removable predictor

The following columns are simultaneous diagnostics. U_i+sum(S involving i) is NOT interpreted as the exact deletion loss for the four-source decomposition.

'''+md(omit)+'''
At the 1990 core, F5100 set, blue-leading,L5,N203, R(C,R) accounts for g=.336470/.216803. Nevertheless, the red predictor participates in synergistic sums .138757/.123355 and also has unique fractions on the target-entropy scale .002395/.003721. The core has unique .044102/.016091 and synergistic sums .115569/.147509. Large pair redundancy therefore coexists with information not represented by that pair atom alone.

A limited candidate for omission assessment is B for the 1991 core,F5100 set,blue-leading,L1,N184: in two bins U(B)=0 and the sum of B-containing synergy is about9.5e-15; its information is allocated redundantly. But at the same point with three bins U(B)/H=.005042 and summed B-synergy=.035595; at L20 in two bins the summed B-synergy is .183012. Thus even this candidate is local and discretization-dependent, not grounds to remove B from the complete lag study.

The proper same-sample omission criterion is

Delta ell_i = [H(Y|X_without_i)−H(Y|X_all)]/H(Y) = I(Y;X_i|X_without_i)/H(Y).

A negligible value could support omitting that predictor for the specified target, history and resolution. The four-source U/R/S atoms do not in general determine the reduced-set MI, so no deletion loss is claimed here. A reduced joint distribution with unchanged target samples/bin edges, or retained subset MI, is needed. No raw histogram or reduced-set estimator run has been introduced. Also, H≈B+C+R in unbinned fluxes does not imply that the binned H label is determined by the three component-bin labels.

## Leakage extrema paired with simultaneous U and S

'''+md(leak)+'''
Highest two-bin leakage occurs for the 1992 red target,total set,red-leading,L30,N205: ell=.967066, so the total explained fraction is only .032934. The leading synergy S(B,R) has f=.291019 but g=.009584; top U(R) is only g=.000030. At that identical point with three bins ell=.796567 and the leading synergy switches to S(H,B),f=.105086,g=.021378. The largest three-bin leakage anywhere occurs for the 1992 core,total set,red-leading,L30,N205: ell=.811338; top S(H,B,C,R) has f=.115753,g=.021838.

A large relative unique contribution at high leakage occurs for the 1993 core,total set,common,L27,N232: U(R) has f=.632408,ell=.797379,g=.128139. At the same point with three bins U(R) has f=.064466,ell=.516736,g=.031154. The difference is allocation sensitivity, not a demonstrated change in physical causality.

Near-zero leakage: 1991 core,F5100 set,common,L4,N194 has ell≈3.16e-14 with two bins, U(C)=.140087,R(B,C,R)=.457864 and largest S(C,R)=.059454 (f and g coincide). With three bins at exactly the same point ell=.079187; top U(B) has f=.101351,g=.093325, and top S(B,C) f=.028719,g=.026445. Occupied coarse histogram cells determine the observed discrete target in the binary sample; this does not establish absence of unobserved physical drivers.

All additional per-target and per-configuration extrema, including low-leakage top-R and cross-U components, are in redundancy_leakage.csv. Fixed-lag examples are separately in selected_redundancy_leakage.csv; all360 paired two/three-bin pair-maxima comparisons are in redundancy_pair_crossbin.csv.
'''
text=text.replace('3940 records',f'{len(a)} records')
(P/'findings.md').write_text(text)
print('Saved findings, records',len(a))
