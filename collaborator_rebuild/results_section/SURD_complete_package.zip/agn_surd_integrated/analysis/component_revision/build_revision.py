from pathlib import Path
import re, shutil

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
OUT=ROOT
old=(BASE/'previous_manuscript.tex').read_text()

def block(label,kind='SURDtable'):
    for m in re.finditer(r'\\begin\{'+kind+r'\}.*?\\end\{'+kind+r'\}',old,re.S):
        if '\\label{'+label+'}' in m.group():return m.group()
    raise ValueError(label)

text=old[:old.index(r'\subsection{Common lags:')]
abstract=r'''We investigate possible causal influences in five historical seasons (1989--1993) of NGC~5548 using the Synergistic--Unique--Redundant Decomposition (SURD). Two four-variable sets contain the blue wing, core and red wing of H$\beta$ together with either total H$\beta$ or the 5100~\AA\ continuum. We examine 7200 decompositions with common and unequal lags, two or three seasonal flux states, and base delays of 1--30~d. We rank the individual named components within each information family, reporting their amplitudes and simultaneous leakage. In 1989, unique continuum information about the core reaches 0.799 and 0.387 of target entropy for two and three states, with leakage 0.047 and 0.276. In 1992, the red-wing history supplies unique information about the future blue wing in both variable sets and both state counts, with peak target-entropy fractions 0.106--0.166. Distinct joint influences also emerge: for the 1991 core, the two-state $S(F,B)$ and $S(F,R)$ components contribute 0.187 and 0.125 at 20~d with leakage 0.087, although the unique continuum term vanishes. Strong core--wing redundancy identifies candidate inputs for simpler predictive models. Large late-lag leakage, reaching approximately 0.96 in the total set, identifies targets for additional driver measurements and richer temporal histories. The resulting seasonal map of individual, shared and joint influences complements the response delays and velocity structure measured by reverberation mapping, and provides specific causal hypotheses for the evolving broad-line region.'''
text=re.sub(r'\\begin\{abstract\}.*?\\end\{abstract\}',lambda m:'\\begin{abstract}\n'+abstract+'\n\\end{abstract}',text,flags=re.S)
intro=r'''We follow the seasonal approach of the recent campaigns using the historical AGN Watch continuum and the corrected H$\beta$ component fluxes published by \citet{WandersPeterson1996}. The total line and its components form one four-variable set; replacing the total by the optical continuum forms a second. Each member is used as a target. Our main results identify the leading named unique, redundant and synergistic components for each epoch, target and flux discretization. We pair each component with its contemporaneous leakage and compare the common- and unequal-lag configurations. This resolves which individual histories and combinations carry the observed information, including modest but distinct joint contributions in a noisy astrophysical system. The extended calculations use the archived component values and preserve their original normalization alongside a target-entropy scale.'''
text=re.sub(r'We follow the seasonal approach.*?\n\nSection~',lambda m:intro+'\n\nSection~',text,count=1,flags=re.S)
oldp='For aggregate comparisons we define'
rank=r'''The primary ranking is performed separately for each named component: $L_{g,a}=\arg\max_{1\leq L\leq30}g_a(L)$. We then order distinct components within the unique, redundant or synergistic family by $g_a(L_{g,a})$, retaining the top three and their simultaneous $f_a$, $\ell$ and lag. Cross-variable unique terms are tabulated separately from target memory. This prevents a large redundant or self-history term from obscuring a distinguished synergy. Each listed component has its own maximizing lag; these maxima are not a decomposition at one common time and must not be summed. The accompanying catalogue also gives the $f_a$ maxima and rankings, and the complete components at selected common lags. An identically zero curve has no defined peak lag. Ranking is descriptive and imposes no significance threshold.

For the supplementary budget comparison in Appendix~\ref{app:budgets}, we define'''
text=text.replace(oldp,rank)
text=text.replace('Conservation of equation~\\eqref{eq:normalizations} checks arithmetic consistency but does not validate the estimated component allocation.','The numerical and sampling diagnostics used to interpret these allocations are collected in Section~\\ref{sec:limits}.')
scope=r'''We use SURD as an observational causal-discovery framework: the named components identify candidate individual and joint influences, shared information, and unresolved driving. A modest component can be scientifically informative when its lag dependence and relative importance recur across state counts or predictor configurations. The causal interpretation assumes appropriate temporal ordering, a causal Markov description, faithfulness and sufficiently stationary statistics \citep{MartinezSanchez2025Thesis}. We treat each season separately and interpret the inferred influences within the specified variables and histories. The optical continuum is a proxy for the unmeasured ionizing driver, while each observed series contributes one past value. Causal leakage is the normalized conditional entropy $\ell$; it measures unresolved information, rather than a luminosity or energy fraction.

Redundancy also guides model reduction \citep[section~4.10]{MartinezSanchez2025Thesis}. A large $R(C,R)$ means that either the core or red-wing history supplies that shared contribution to the chosen target. Their other unique and synergistic contributions determine whether both histories remain useful. For an entire predictor to be omitted, the relevant information loss is
\begin{equation}
\begin{aligned}
D_i&=I(Y;X_i\mid\mathbf X_{-i})\\
&=H(Y\mid\mathbf X_{-i})-H(Y\mid\mathbf X),\\
D_i/H(Y)&=\ell_{-i}-\ell,
\end{aligned}
\label{eq:predictor_omission}
\end{equation}
where $\mathbf X_{-i}$ retains the other predictors, on the same target-date sample. A zero loss permits omission without loss of predictive information; a small loss motivates a simpler model. The saved full-set components identify candidates for this test, while evaluating $D_i$ requires the underlying joint histogram or reduced-set information estimates.'''
text=re.sub(r'The causal interpretation of SURD assumes.*?\\section\{SURD components',lambda m:scope+'\n\n\\section{SURD components',text,count=1,flags=re.S)
text=text.replace('The summary tables and added budget figure are recalculated from these component values and the corresponding leakage, while the four original component plots are retained from the atlases;', 'The individual-component tables and new component figure are recalculated from these values and their leakage; all four original component plots and the earlier budget figure are retained;')
text=text.replace('No amplitude cut is used to select a nonzero continuum peak.','No amplitude cut is used to select nonzero component peaks.')
text=text.replace('Grid tuples give the common-lag range requiring all five series;', 'Grid tuples give the range over common-lag targets and both four-variable sets;')

parts=['section_results.tex','section_comparison.tex','section_astro.tex','section_conclusion.tex']
for name in parts:text+='\n'+(BASE/name).read_text()+'\n'
for label in ['fig:ep_common_1989_continuum_wings_core','fig:ep_common_1992_continuum_wings_red','fig:ep_common_1993_total_wings_core','fig:ep_blue_leading_1992_continuum_wings_core','fig:budgets']:
    text=text.replace('% FIGURE '+label,block(label,'SURDfigure'))
for label in ['tab:mixed_examples','tab:ep_lu','tab:ep_xi','tab:leakage_means','tab:paired']:
    text=text.replace('% TABLE '+label,block(label))
for name in ['cross_u_total_wings','cross_u_continuum_wings','synergistic_total_wings','synergistic_continuum_wings','redundant_total_wings','redundant_continuum_wings']:
    text=text.replace('% RANK_TABLE '+name,(BASE/'rankings/tables'/f'{name}.tex').read_text())
for name in ['directed_1992','selected_mixed','leakage_cases']:
    token='% NEW_TABLE '+name
    if token in text:text=text.replace(token,(BASE/'tables'/f'{name}.tex').read_text())
figure=BASE/'figures/specific_components_caption.tex'
if figure.exists():
    ftext=figure.read_text().replace('fig:specific_components','fig:named_components')
    ftext=ftext.replace('These are observational information estimates,\nwithout calibrated significance or an identification of direct physical\ncoupling between emitting regions.','The individual components and their simultaneous leakage identify the resolved pathways discussed in the text.')
    text=text.replace('% NEW_COMPONENT_FIGURE',ftext)
else: text=text.replace('% NEW_COMPONENT_FIGURE','% New figure pending')

tail=old[old.index(r'\section*{Data and code availability}'):old.index(r'\onecolumn')]
tail=tail.replace('scripts used for the new aggregations.','scripts used for the named-component rankings, directional comparisons and simultaneous leakage calculations. A supplementary catalogue gives the top three cross-unique, redundant and synergistic components for all unequal-lag cases; full-precision CSVs retain every component maximum under both normalizations and all self-history terms.')
text+=tail
text+=r'''
\clearpage
\onecolumn
\appendix
\section{Supplementary information budgets}
\label{app:budgets}
The principal analysis resolves named components. Figure~\ref{fig:budgets} retains the earlier aggregate view as a supplementary consistency check: panels (a,b) compare the continuum-unique $f$ and $g$ maxima for the 1989 core; panel (c) shows why zero unique continuum information in 1991 can coexist with shared and joint information; panel (d) displays the matched-set leakage and synergy-budget changes. The individual pathways responsible for these budgets are identified in Tables~\ref{tab:synergistic_total_wings}--\ref{tab:redundant_continuum_wings}. Replacing $H$ by $F$ lowers lag-averaged leakage in all 90 matched epoch--line-target--configuration--bin comparisons, with common-lag mean reductions of 0.205/0.160 for two/three states. Equal-count common-lag epochs 1989--1992 give reductions of 0.231/0.170. These fitted information differences complement the named-component interpretation.
'''
budget=block('fig:budgets','SURDfigure')
budget=budget.replace(r'\begin{SURDfigure}',r'\begin{minipage}{\textwidth}\makeatletter\let\@makecaption\SFB@makefigurecaption\makeatother').replace(r'\end{SURDfigure}',r'\end{minipage}').replace(r'\caption{',r'\captionof{figure}{')
text+=budget
# Retain the original dominant-component inventory as a secondary appendix.
dom=old[old.index(r'\onecolumn'):]
dom=dom.replace('\\onecolumn\n\\appendix','\\clearpage\n\\onecolumn')
text+=dom
text=text.replace('reaching approximately 0.96','reaching approximately 0.97')
text=text.replace('Two four-variable sets contain the blue wing, core and red wing of H$\\beta$ together with either total H$\\beta$ or the 5100~\\AA\\ continuum.', 'Two four-variable sets contain the blue wing ($B$), core ($C$) and red wing ($R$) of H$\\beta$ together with either total H$\\beta$ ($H$) or the 5100~\\AA\\ continuum ($F$).')
text=text.replace(r'\begin{table*}[p]',r'\begin{table*}')
text=text.replace('Table~\\ref{tab:paired} provides the comparison with the line targets held fixed.','The text also compares the two sets with the line targets held fixed.')
text=text.replace('largest individual component of every scan, including self-memory','largest individual component of every common-lag scan, including self-memory')
text=text.replace('its absolute magnitude is established by pairing it with leakage at the same lag','its estimated target-entropy contribution is quantified by pairing it with leakage at the same lag')
text=text.replace('retain the original common-lag examples and display','show the common-lag examples and display')
text=text.replace('retains the full 1992 core scan','shows the full 1992 core scan')
text=re.sub(r' This is the original component plot, retained from page (\d+) of the ([\w-]+) atlas\.',r' Source: \2 atlas, page \1.',text)
assert not re.search(r'% (RANK_TABLE|NEW_TABLE|TABLE|FIGURE|NEW_COMPONENT)',text)
(OUT/'agn_surd_integrated.tex').write_text(text)
shutil.copy2(BASE/'previous_refs.bib',OUT/'agn_surd_integrated_refs.bib')
for name in ['specific_components.pdf','specific_components.png','specific_components_plot_data.csv']:
    p=BASE/'figures'/name
    if p.exists():shutil.copy2(p,OUT/'figures'/name)
print('Wrote revised manuscript:',len(text.split()),'words/tokens')
