"""Reproduce compact manuscript tables and one numerical figure from saved SURD outputs.

This script performs no statistical tests and reruns no SURD distributions.
Tables keep fractions and leakage at the same selected lag. Maxima are sample
descriptions, not detections; all displayed decimals are rounded to two places.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]/'data'
BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'generated_tables'
FIG = BASE / 'generated_figures'
EXT = BASE / 'mixed_extended'
KEY = ['epoch','subset','target','config','bins','lag_days']
SYMBOL = {'continuum':'F','total':'H','blue':'B','core':'C','red':'R'}
SET = {'total_wings':'H','continuum_wings':'F'}
TARGETS = {'total_wings':['total','blue','core','red'], 'continuum_wings':['continuum','blue','core','red']}
MASTER = []


def atom(s):
    kind, members = s[:-1].split('(')
    return kind + '(' + ','.join(SYMBOL[x] for x in members.split(',')) + ')'


def num(x):
    return f'{x:.2f}'


def entry(r, with_atom=False):
    if pd.isna(r.lag_days):
        return r'$\text{---}$'
    values = f'{int(r.lag_days)},{num(r.fraction)},{num(r.normalized_leakage)},{num(r.g)}'
    return '$' + (atom(r.component)+':' if with_atom else '') + '(' + values + ')$'


def table(name, caption, label, columns, header, body, size=r'\small'):
    text = '\n'.join([
        r'\begin{table*}[p]',r'\centering',size,
        r'\caption{'+caption+'}',r'\label{'+label+'}',
        r'\setlength{\tabcolsep}{4pt}',r'\begin{tabular}{'+columns+'}',
        r'\toprule',header+r' \\',r'\midrule',*body,
        r'\bottomrule',r'\end{tabular}',r'\end{table*}',''])
    (OUT / name).write_text(text)


def save_exact(df, name, table_id):
    df.to_csv(OUT / (name+'.csv'),index=False)
    MASTER.append(df.assign(table_id=table_id))


def main():
    OUT.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True)
    a=pd.read_csv(ROOT/'individual_components.csv.gz')
    s=pd.read_csv(ROOT/'support_and_leakage.csv')
    d=a.merge(s,on=KEY,validate='many_to_one')
    d['g']=d.fraction*(1-d.normalized_leakage)
    common=d[d.config.eq('common')]
    grp=['epoch','subset','target','bins']
    dominant=common.loc[common.groupby(grp).g.idxmax()].copy()
    dominant['selection']='max_g_over_components_and_lags'
    save_exact(dominant,'table1_dominant_exact','dominant')
    body=[]
    for subset in TARGETS:
        for epoch in range(1989,1994):
            for i,target in enumerate(TARGETS[subset]):
                q=dominant[(dominant.subset==subset)&(dominant.epoch==epoch)&(dominant.target==target)].set_index('bins')
                body.append('$'+SET[subset]+'$ & '+(str(epoch) if i==0 else '')+' & $'+SYMBOL[target]+'$ & '+entry(q.loc[2],True)+' & '+entry(q.loc[3],True)+r' \\')
            if epoch!=1993:body.append(r'\addlinespace[2pt]')
        if subset=='total_wings':body.append(r'\midrule')
    table('table1_dominant.tex',
          r'Largest common-lag individual contribution to target entropy for every epoch, subset and target. An entry is $a:(L,f_a,\ell,g_a)$, selected by maximizing $g_a=(1-\ell)f_a$ over all 26 components and 30 lags separately for each bin choice. Leakage is evaluated at the selected lag; this criterion does not maximize $f_a$ alone. $F,H,B,C,R$ denote continuum, total, blue, core and red fluxes. Predictor subscripts identify the unique variable or redundant/synergistic group; the target is listed separately. Self-history is included. These descriptive extrema have no significance calibration or lag-error estimate.',
          'tab:dominant_components','cccll',r'Subset & Epoch & Target & Two bins: $a:(L,f_a,\ell,g_a)$ & Three bins: $a:(L,f_a,\ell,g_a)$',body,r'\scriptsize')

    q=common[common.subset.eq('continuum_wings')&common.target.ne('continuum')&common.component.eq('U(continuum)')]
    peaks=q.loc[q.groupby(['epoch','target','bins']).fraction.idxmax()].copy()
    peaks['peak_defined']=peaks.fraction>0
    peaks.loc[~peaks.peak_defined,'lag_days']=np.nan
    peaks['selection']='max_f_of_unique_continuum_over_lags'
    # At an identically zero component no preferred simultaneous leakage exists.
    peaks.loc[~peaks.peak_defined,['normalized_leakage','tuple_count','joint_mi_bits']]=np.nan
    save_exact(peaks,'table2_continuum_peaks_exact','continuum_peaks')
    body=[]
    for epoch in range(1989,1994):
        for i,target in enumerate(['blue','core','red']):
            qq=peaks[(peaks.epoch==epoch)&(peaks.target==target)].set_index('bins')
            body.append((str(epoch) if i==0 else '')+' & $'+SYMBOL[target]+'$ & '+entry(qq.loc[2])+' & '+entry(qq.loc[3])+r' \\')
        if epoch!=1993:body.append(r'\addlinespace[2pt]')
    table('table2_continuum_peaks.tex',
          r'Unique continuum contributions to the line targets of $F$ with common lags. Each tuple gives $(L,f_F,\ell,g_F)$ at the maximum of $f_F=U_F/I$ over 1--30~d, with $g_F=U_F/H(Y)$. Leakage is evaluated at that same lag. A dash means the unique continuum term is zero throughout the scan, so no preferred peak lag or simultaneous leakage is assigned. All nonzero peaks are included without a detection threshold. Values are descriptive estimates without uncertainty bars.',
          'tab:continuum_peaks','ccll',r'Epoch & Target & Two bins: $(L,f_F,\ell,g_F)$ & Three bins: $(L,f_F,\ell,g_F)$',body)

    ell=s[s.config.eq('common')].groupby(['epoch','subset','bins']).normalized_leakage.agg(mean_leakage='mean',minimum_leakage='min',maximum_leakage='max').reset_index()
    ell['selection']='unweighted_all_four_targets_and_30_common_lags'
    save_exact(ell,'table3_epoch_leakage_exact','epoch_leakage')
    body=[]
    for epoch in range(1989,1994):
        for subset in TARGETS:
            qq=ell[(ell.epoch==epoch)&(ell.subset==subset)].set_index('bins')
            body.append(str(epoch)+' & $'+SET[subset]+'$ & '+num(qq.loc[2].mean_leakage)+'/'+num(qq.loc[3].mean_leakage)+' & $['+num(qq.loc[2].minimum_leakage)+','+num(qq.loc[2].maximum_leakage)+']$ & $['+num(qq.loc[3].minimum_leakage)+','+num(qq.loc[3].maximum_leakage)+']$'+r' \\')
    table('table3_epoch_leakage.tex',
          r'Common-lag leakage by epoch and subset. Means are unweighted averages over all four targets and 30 base lags; the mean column gives two-/three-bin values. Ranges are minima and maxima over the same targets and lags, not confidence intervals. A printed zero may reflect rounding or numerical precision. The statistics are not corrected for effective sample size, interpolation or histogram-estimation effects.',
          'tab:epoch_leakage','cclll',r'Epoch & Subset & Mean $\ell$, 2/3 bins & Range, two bins & Range, three bins',body)

    examples=[
        (1989,'continuum_wings','core','blue_leading','U(continuum)'),
        (1992,'continuum_wings','red','red_leading','U(continuum)'),
        (1992,'total_wings','blue','red_leading','R(total,blue,core,red)'),
        (1991,'continuum_wings','core','red_leading','S(continuum,red)'),
        (1993,'continuum_wings','red','red_leading','U(red)'),
        (1993,'total_wings','core','red_leading','U(red)')]
    rows=[];body=[]
    for exid,(epoch,subset,target,config,component) in enumerate(examples,1):
        qq=d[(d.epoch==epoch)&(d.subset==subset)&(d.target==target)&(d.config==config)&(d.component==component)]
        qq=qq.loc[qq.groupby('bins').fraction.idxmax()].copy()
        qq['example_id']=exid;qq['selection']='max_f_of_specified_component_over_lags';rows.append(qq)
        qq=qq.set_index('bins')
        off='B+5' if config=='blue_leading' else 'R+5'
        body.append(str(epoch)+' & $'+SET[subset]+'$ & $'+SYMBOL[target]+'$ & $'+off+'$ & $'+atom(component)+'$ & '+entry(qq.loc[2])+' & '+entry(qq.loc[3])+r' \\')
    mixed=pd.concat(rows,ignore_index=True);save_exact(mixed,'table4_mixed_examples_exact','mixed_examples')
    table('table4_mixed_examples.tex',
          r'Selected unequal-lag examples. For each specified component and each bin choice, the entry $(L,f_a,\ell,g_a)$ is taken at its maximum relative fraction $f_a$ over base lags 1--30~d. This selects a specified component, not the largest component overall. $B+5$ and $R+5$ indicate that the named predictor is sampled 5~d further back; all others are sampled at $L$. If the shifted wing is also the target, its self-history is shifted too. The examples illustrate sizable contributions and sensitivity; no statistical significance or uncertainty is assigned.',
          'tab:mixed_examples','ccccc ll',r'Epoch & Set & Target & Offset & Component & Two bins: $(L,f_a,\ell,g_a)$ & Three bins: $(L,f_a,\ell,g_a)$',body,r'\scriptsize')

    paired=pd.read_csv(EXT/'subset_paired_means_by_epoch.csv')
    save_exact(paired,'table5_paired_subsets_exact','paired_subsets')
    body=[];configs=[('common','Common'),('blue_leading',r'$B+5$'),('red_leading',r'$R+5$')]
    for epoch in range(1989,1994):
        for i,(config,name) in enumerate(configs):
            qq=paired[(paired.epoch==epoch)&(paired.config==config)].set_index('bins')
            fmt=lambda field:'/'.join(f'{qq.loc[b,field]:+.2f}' for b in [2,3])
            body.append((str(epoch) if i==0 else '')+' & '+name+' & '+fmt('delta_normalized_leakage')+' & '+fmt('delta_g_S')+r' \\')
        if epoch!=1993:body.append(r'\addlinespace[2pt]')
    table('table5_paired_subsets.tex',
          r'Matched comparison of the two predictor subsets for the shared blue, core and red targets. Entries give two-/three-bin values of the arithmetic mean of the paired differences, F5100 set minus total subset, over three targets and 30 base lags. $G_S=\sum_A S_A/H(Y)$ sums all eleven synergistic terms. Negative $\Delta\ell$ denotes smaller estimated unresolved uncertainty after replacing $H$ by $F$. Tuple counts agree in every comparison except common-lag 1993, where $F$ has one or two fewer tuples. Equal counts do not certify identical dates; these are descriptive differences, not an identical-date controlled re-estimation or significance test.',
          'tab:paired_subsets','ccll',r'Epoch & Configuration & $\Delta\ell$, 2/3 bins & $\Delta G_S$, 2/3 bins',body)
    pd.concat(MASTER,ignore_index=True,sort=False).to_csv(OUT/'master_table_rows_exact.csv',index=False)

    # Scientific figure: exact data are saved alongside the figure.
    plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.titlesize':10,'axes.labelsize':9,
                         'legend.fontsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'svg.fonttype':'none'})
    fig,axs=plt.subplots(2,2,figsize=(10.5,7.1),layout='constrained')
    figdata=[]
    for b,ax,letter in [(2,axs[0,0],'a'),(3,axs[0,1],'b')]:
        z=common[(common.epoch==1989)&common.subset.eq('continuum_wings')&common.target.eq('core')&common.bins.eq(b)&common.component.eq('U(continuum)')].sort_values('lag_days')
        ax.plot(z.lag_days,z.fraction,color='#1769aa',label=r'$f_{U(F)}$',lw=1.8)
        ax.plot(z.lag_days,z.g,color='#b34c00',label=r'$g_{U(F)}$',lw=1.8)
        ax.plot(z.lag_days,z.normalized_leakage,color='#444444',label=r'Leakage $\ell$',ls='--',lw=1.5)
        ax.set(title=f'({letter}) 1989 core target, F5100 set, {b} bins',xlabel='Common lag L [d]',ylabel='Information fraction',xlim=(1,30),ylim=(0,1))
        ax.legend(loc='upper left',frameon=False);ax.grid(axis='y',alpha=.18)
        figdata.append(z.assign(panel=letter))
    budgets=pd.read_csv(EXT/'decomposition_budgets.csv')
    z=budgets[(budgets.epoch==1991)&budgets.subset.eq('continuum_wings')&budgets.target.eq('core')&budgets.config.eq('common')&budgets.bins.eq(2)].sort_values('lag_days')
    ax=axs[1,0]
    ax.stackplot(z.lag_days,z.g_U_self,z.g_U_cross,z.g_R,z.g_S,z.normalized_leakage,
                 colors=['#354a7a','#5996cc','#4d9d75','#e2af46','#d9d9d9'],
                 labels=[r'$G_{U,\mathrm{self}}$',r'$G_{U,\mathrm{cross}}$',r'$G_R$',r'$G_S$',r'$\ell$'],linewidth=.2,edgecolor='white')
    ax.set(title='(c) 1991 core target, F5100 set, 2 bins',xlabel='Common lag L [d]',ylabel='Target-entropy budget',xlim=(1,30),ylim=(0,1))
    ax.legend(loc='lower left',ncol=3,frameon=True,framealpha=.92,columnspacing=.8,handlelength=1.4)
    figdata.append(z.assign(panel='c'))
    ax=axs[1,1]
    zz=paired[paired.config.eq('common')]
    for b,ls,m in [(2,'-','o'),(3,'--','s')]:
        z=zz[zz.bins.eq(b)].sort_values('epoch')
        ax.plot(z.epoch,z.delta_normalized_leakage,color='#7d3c98',marker=m,ls=ls,lw=1.7,label=rf'$\Delta\ell$, {b} bins')
        ax.plot(z.epoch,z.delta_g_S,color='#b17700',marker=m,ls=ls,lw=1.7,label=rf'$\Delta G_S$, {b} bins')
        figdata.append(z.assign(panel='d'))
    ax.axhline(0,color='#444444',lw=.8)
    ax.set(title='(d) Matched line targets: F5100 minus total set',xlabel='Epoch',ylabel='Mean paired difference',xticks=list(range(1989,1994)),ylim=(-.36,.23))
    ax.legend(loc='upper left',ncol=2,frameon=False,columnspacing=.8,handlelength=1.5)
    ax.grid(axis='y',alpha=.18)
    fig.savefig(FIG/'surd_information_budgets.png',dpi=300)
    fig.savefig(FIG/'surd_information_budgets.svg')
    fig.savefig(FIG/'surd_information_budgets.pdf')
    plt.close(fig)
    pd.concat(figdata,ignore_index=True,sort=False).to_csv(FIG/'surd_information_budgets_data.csv',index=False)
    caption=(r'Observed SURD information budgets. Panels (a,b) show the relative unique continuum contribution $f_F$, its target-entropy contribution $g_F$, and simultaneous leakage for the 1989 core target with two and three bins. Their peaks need not coincide. Panel (c) sums the 1991 core contributions into unique self-history, unique cross-variable, redundant and synergistic fractions of target entropy; adding leakage closes the budget to one. Panel (d) compares the same three line targets between subsets, averaging paired differences over targets and common lags. Values are empirical estimates from the saved interpolated data; lines guide the eye and no uncertainty bars or statistical-significance claims are implied.')
    (FIG/'surd_information_budgets_caption.tex').write_text(caption+'\n')
    (OUT/'README.txt').write_text('Generated from saved CSVs by build_tables_figures.py. Tables use F=continuum,H=total,B=blue,C=core,R=red. Include tables with booktabs,amsmath. Figure PNG is 300 dpi; SVG is editable. Exact unrounded table and figure values are supplied as CSV. No hypothesis tests or identical-date reruns were performed.\n')
    print('Generated five tables, five exact table CSVs, one master CSV, PNG/SVG figure and figure data/caption.')


if __name__=='__main__':main()
