from pathlib import Path
import pandas as pd, numpy as np
p=Path(__file__).resolve().parent
root=p.parents[1]/'data'
c=pd.read_csv(root/'individual_components.csv.gz')
s=pd.read_csv(root/'support_and_leakage.csv')
k=['epoch','subset','target','config','bins','lag_days']
d=c.merge(s,on=k,validate='many_to_one')
d=d[d['subset'].eq('continuum_wings') & ((d.epoch.eq(1991)&d.target.eq('core')) | (d.epoch.eq(1993)&d.target.eq('red')))].copy()
d['hfrac']=d.fraction*(1-d.normalized_leakage)
d['hasF']=d.component.str.contains(r'\bcontinuum\b',regex=True)
rows=[]
for key,z in d.groupby(k):
 row=dict(zip(k,key)); row.update(tuple_count=int(z.tuple_count.iloc[0]),leak=float(z.normalized_leakage.iloc[0]),MI=float(z.joint_mi_bits.iloc[0]))
 for kind in ['U','R','S']:
  a=z[z.hasF & z.kind.eq(kind)]
  row[kind+'_F_bits']=a.bits.sum(); row[kind+'_F_fraction']=a.fraction.sum(); row[kind+'_F_hfrac']=a.hfrac.sum()
 for met in ['bits','fraction','hfrac']:
  row['J_F_'+met]=sum(row[x+'_F_'+met] for x in ['U','R','S'])
  row['self_U_'+met]=z.loc[z.component.eq('U('+row['target']+')'),met].iloc[0]
 for kind in ['R','S']:
  a=z[z.hasF & z.kind.eq(kind)]; r=a.loc[a.hfrac.idxmax()]
  row['strongest_F_'+kind]=r.component;row['strongest_F_'+kind+'_hfrac']=r.hfrac;row['strongest_F_'+kind+'_fraction']=r.fraction
 r=z.loc[z.hfrac.idxmax()];row['strongest_atom']=r.component;row['strongest_atom_hfrac']=r.hfrac
 row['self_U_strictly_max_atom']=row['self_U_hfrac']>z.loc[~z.component.eq('U('+row['target']+')'),'hfrac'].max()
 rows.append(row)
a=pd.DataFrame(rows);a.to_csv(p/'per_lag.csv',index=False)
rows=[]
for key,z in a.groupby(['epoch','target','config','bins']):
 row=dict(zip(['epoch','target','config','bins'],key))
 row['U_F_max_hfrac']=z.U_F_hfrac.max();row['U_F_positive_lags']=int((z.U_F_hfrac>1e-12).sum())
 for var in ['J_F','R_F','S_F','self_U']:
  r=z.loc[z[var+'_hfrac'].idxmax()]
  row[var+'_min_hfrac']=z[var+'_hfrac'].min();row[var+'_max_hfrac']=r[var+'_hfrac'];row[var+'_argmax_lag']=int(r.lag_days)
 row['self_gt_JF_lags']=int((z.self_U_hfrac>z.J_F_hfrac).sum()); row['self_strict_max_atom_lags']=int(z.self_U_strictly_max_atom.sum())
 r=z.loc[z.J_F_hfrac.idxmax()]
 for col in ['leak','self_U_hfrac','U_F_hfrac','R_F_hfrac','S_F_hfrac','J_F_fraction']:
  row['at_JFmax_'+col]=r[col]
 for kind in ['R','S']:
  r=z.loc[z['strongest_F_'+kind+'_hfrac'].idxmax()]
  row['strongest_F_'+kind]=r['strongest_F_'+kind];row['strongest_F_'+kind+'_max_hfrac']=r['strongest_F_'+kind+'_hfrac'];row['strongest_F_'+kind+'_fraction']=r['strongest_F_'+kind+'_fraction'];row['strongest_F_'+kind+'_argmax_lag']=int(r.lag_days)
 rows.append(row)
b=pd.DataFrame(rows);b.to_csv(p/'config_summary.csv',index=False)
print(b.to_string(index=False,float_format=lambda x:f'{x:.9f}'))
print('\nAt lag 1:')
print(a[a.lag_days.eq(1)][['epoch','target','config','bins','leak','U_F_hfrac','R_F_hfrac','S_F_hfrac','J_F_hfrac','self_U_hfrac','strongest_atom']].to_string(index=False,float_format=lambda x:f'{x:.9f}'))
print('\nCHECK BOUNDS: minimum JF-I(Y;F)',a.S_F_hfrac.min(),'max JF + leak', (a.J_F_hfrac+a.leak).max())
