"""Recreate exact component extrema used in the figure-specific discussion."""
from pathlib import Path
import pandas as pd

root=Path(__file__).resolve().parents[1]
keys=['epoch','subset','target','config','bins','lag_days']
a=pd.read_csv(root/'data/individual_components.csv.gz')
b=pd.read_csv(root/'data/support_and_leakage.csv')
d=a.merge(b,on=keys,validate='many_to_one')
d['g']=d.fraction*(1-d.normalized_leakage)
cases=[('fig2',1992,'continuum_wings','red','common'),
       ('fig4',1992,'continuum_wings','core','blue_leading'),
       ('fig4_comparator',1992,'continuum_wings','core','common'),
       ('fig1',1989,'continuum_wings','core','common'),
       ('fig3',1993,'total_wings','core','common')]
rows=[]
for case,epoch,subset,target,config in cases:
 for bins in [2,3]:
  q=d[(d.epoch==epoch)&(d.subset==subset)&(d.target==target)&(d.config==config)&(d.bins==bins)]
  groups={'UF':q[q.component.eq('U(continuum)')],
          'R':q[q.kind.eq('R')],'S':q[q.kind.eq('S')],
          'SFC':q[q.component.eq('S(continuum,core)')],
          'selfU':q[q.component.eq('U('+target+')')]}
  for name,z in groups.items():
   if z.empty:continue
   for metric in ['fraction','g']:
    r=z.loc[z[metric].idxmax()]
    rows.append(dict(case=case,bins=bins,component_class=name,ranked_by=metric,
                     component=r.component,lag=int(r.lag_days),f=r.fraction,
                     ell=r.normalized_leakage,g=r.g))
pd.DataFrame(rows).to_csv(root/'analysis/comparison_numbers/figure_component_extrema.csv',index=False)
print('Recreated figure-discussion extrema, with simultaneous leakage.')
