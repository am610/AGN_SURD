# Exact comparison audit

Redshift z = 0.01717 (Lu and Xi papers). Rest-frame lag = observed-frame lag/(1+z). Every strictly nonzero common-lag U(F) peak is retained; zero plateaus have undefined lag. The flag f<0.05 is only a descriptive weak-peak flag and is never a selection filter or a significance test. Spearman coefficient is computed from ranks only; no new significance test.

## Seasonal f-max comparisons

 epoch  bins  nonzero_line_peaks  median_peak_observed_days  median_peak_rest_days  Lu_rest_lag_days  median_rest_offset_days
  1989     2                   3                23.00000000            22.61175615       19.70000000               2.91175615
  1989     3                   3                25.00000000            24.57799581       19.70000000               4.87799581
  1990     2                   3                27.00000000            26.54423548       18.60000000               7.94423548
  1990     3                   3                19.00000000            18.67927682       18.60000000               0.07927682
  1991     2                   2                20.50000000            20.15395657       15.90000000               4.25395657
  1991     3                   3                20.00000000            19.66239665       15.90000000               3.76239665
  1992     2                   3                17.00000000            16.71303715       11.00000000               5.71303715
  1992     3                   3                19.00000000            18.67927682       11.00000000               7.67927682
  1993     2                   2                23.00000000            22.61175615       13.00000000               9.61175615
  1993     3                   3                20.00000000            19.66239665       13.00000000               6.66239665

## Aggregate f-max comparisons

 bins  nonzero_line_peaks  season_count  median_of_five_season_rest_offsets_days  median_individual_rest_peak_offsets_days  spearman_five_season_lags  min_individual_rest_offset_days  max_individual_rest_offset_days  positive_individual_rest_offsets
    2                  13             5                               5.71303715                                6.66239665                 0.66688593                      -0.03760335                      12.56111564                                12
    3                  15             5                               4.87799581                                4.74551648                 0.52704628                      -3.11944218                      18.49359497                                11

## Wing contrasts

 epoch  bins peak_selection  red_minus_blue_observed_days  red_minus_blue_rest_days  blue_fraction  red_fraction  undefined_zero_peak  weak_nonzero_peak_below_005
  1989     2           fmax                   -7.00000000               -6.88183883     0.75385428    0.82890335                False                        False
  1989     2           gmax                   -4.00000000               -3.93247933     0.72107798    0.79567918                False                        False
  1989     3           fmax                   -6.00000000               -5.89871899     0.49259374    0.31256927                False                        False
  1989     3           gmax                   -8.00000000               -7.86495866     0.47544799    0.31256927                False                        False
  1990     2           fmax                    6.00000000                5.89871899     0.80444597    0.61666537                False                        False
  1990     2           gmax                    5.00000000                4.91559916     0.78811630    0.56744354                False                        False
  1990     3           fmax                    0.00000000                0.00000000     0.35202917    0.35273240                False                        False
  1990     3           gmax                    0.00000000                0.00000000     0.35202917    0.35273240                False                        False
  1991     2           fmax                   -5.00000000               -4.91559916     0.28660031    0.44039706                False                        False
  1991     2           gmax                   -5.00000000               -4.91559916     0.28660031    0.44039706                False                        False
  1991     3           fmax                   -8.00000000               -7.86495866     0.00922721    0.22738638                False                         True
  1991     3           gmax                   -8.00000000               -7.86495866     0.00922721    0.22738638                False                         True
  1992     2           fmax                   -5.00000000               -4.91559916     0.61761226    0.60863019                False                        False
  1992     2           gmax                   -6.00000000               -5.89871899     0.55566142    0.56001208                False                        False
  1992     3           fmax                   -8.00000000               -7.86495866     0.26321239    0.35966705                False                        False
  1992     3           gmax                   -8.00000000               -7.86495866     0.26321239    0.35966705                False                        False
  1993     2           fmax                           NaN                       NaN     0.61334126    0.00000000                 True                        False
  1993     2           gmax                           NaN                       NaN     0.61334126    0.00000000                 True                        False
  1993     3           fmax                  -15.00000000              -14.74679749     0.32077050    0.14675241                False                        False
  1993     3           gmax                  -15.00000000              -14.74679749     0.32077050    0.14675241                False                        False

## Leakage extrema counts

 bins  curves  minimum_at_1_day  maximum_at_or_above_20_days  maximum_above_20_days
    2      40                36                           35                     35
    3      40                38                           34                     32

## Common mean leakage by epoch/subset/bin

 epoch          subset  bins  mean_leakage  min_tuples  max_tuples
  1989 continuum_wings     2    0.36609379         134         196
  1989 continuum_wings     3    0.27284059         134         196
  1989     total_wings     2    0.60651544         134         192
  1989     total_wings     3    0.44581451         134         192
  1990 continuum_wings     2    0.44807890         161         232
  1990 continuum_wings     3    0.29827323         161         232
  1990     total_wings     2    0.61302521         161         230
  1990     total_wings     3    0.48968666         161         230
  1991 continuum_wings     2    0.38811812         133         211
  1991 continuum_wings     3    0.32424452         133         211
  1991     total_wings     2    0.48138065         133         209
  1991     total_wings     3    0.33689607         133         209
  1992 continuum_wings     2    0.50481481         211         244
  1992 continuum_wings     3    0.38394762         211         244
  1992     total_wings     2    0.65122351         211         243
  1992     total_wings     3    0.49104155         211         243
  1993 continuum_wings     2    0.60128666         231         260
  1993 continuum_wings     3    0.40049602         231         260
  1993     total_wings     2    0.70243303         232         261
  1993     total_wings     3    0.51267675         232         261

## Common mean leakage, both subsets combined

 epoch  bins  mean_leakage
  1989     2    0.48630462
  1989     3    0.35932755
  1990     2    0.53055205
  1990     3    0.39397995
  1991     2    0.43474938
  1991     3    0.33057030
  1992     2    0.57801916
  1992     3    0.43749458
  1993     2    0.65185984
  1993     3    0.45658639

## Common mean leakage, all epochs

         subset  bins  mean_leakage
continuum_wings     2    0.46167845
continuum_wings     3    0.33596040
    total_wings     2    0.61091557
    total_wings     3    0.45522311
