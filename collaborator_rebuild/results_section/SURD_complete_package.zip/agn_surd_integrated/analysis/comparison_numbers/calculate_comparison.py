from pathlib import Path
import json
import pandas as pd
import numpy as np
HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]/'data'
z=0.01717
rest=1/(1+z)
refs=pd.Series({1989:19.7,1990:18.6,1991:15.9,1992:11.,1993:13.},name='Lu_rest_lag_days')
c=pd.read_csv(BASE/'individual_components.csv.gz');s=pd.read_csv(BASE/'support_and_leakage.csv')
keys=['epoch','subset','target','config','bins','lag_days']
d=c.merge(s,on=keys,validate='many_to_one')
d['entropy_fraction']=d.fraction*(1-d.normalized_leakage)
u=d[d.config.eq('common')&d.subset.eq('continuum_wings')&d.component.eq('U(continuum)')&~d.target.eq('continuum')].copy()
peaks=[]
for metric in ['fraction','entropy_fraction']:
 for group,v in u.groupby(['epoch','target','bins'],sort=True):
  r=v.loc[v[metric].idxmax()].copy();r['peak_selection']='fmax' if metric=='fraction' else 'gmax';r['is_identically_zero']=bool((v.fraction==0).all());r['peak_weak_below_005']=bool(r.fraction<.05 and not r.is_identically_zero)
  r['peak_lag_observed_days']=float(r.lag_days) if not r.is_identically_zero else np.nan
  r['peak_lag_rest_days']=r.peak_lag_observed_days*rest
  r['Lu_rest_lag_days']=refs.loc[r.epoch]
  r['rest_offset_days']=r.peak_lag_rest_days-r.Lu_rest_lag_days
  peaks.append(r)
peaks=pd.DataFrame(peaks).reset_index(drop=True)
peakcols=['epoch','target','bins','peak_selection','peak_lag_observed_days','peak_lag_rest_days','fraction','entropy_fraction','normalized_leakage','Lu_rest_lag_days','rest_offset_days','is_identically_zero','peak_weak_below_005']
peaks[peakcols].to_csv(HERE/'individual_peaks_both_selections.csv',index=False)
f=peaks[(peaks.peak_selection=='fmax')&~peaks.is_identically_zero].copy()
season=f.groupby(['epoch','bins']).agg(nonzero_line_peaks=('target','size'),median_peak_observed_days=('peak_lag_observed_days','median'),median_peak_rest_days=('peak_lag_rest_days','median')).reset_index()
season['median_peak_rest_days']=season.median_peak_observed_days*rest
season['Lu_rest_lag_days']=season.epoch.map(refs);season['median_rest_offset_days']=season.median_peak_rest_days-season.Lu_rest_lag_days
season.to_csv(HERE/'season_comparison_fmax_all_nonzero.csv',index=False)
summary=[]
for bins,v in season.groupby('bins'):
 fi=f[f.bins==bins]
 summary.append({'bins':int(bins),'nonzero_line_peaks':len(fi),'season_count':len(v),'median_of_five_season_rest_offsets_days':v.median_rest_offset_days.median(),'median_individual_rest_peak_offsets_days':fi.rest_offset_days.median(),'spearman_five_season_lags':v.median_peak_observed_days.rank().corr(v.Lu_rest_lag_days.rank()),'min_individual_rest_offset_days':fi.rest_offset_days.min(),'max_individual_rest_offset_days':fi.rest_offset_days.max(),'positive_individual_rest_offsets':int((fi.rest_offset_days>0).sum())})
summary=pd.DataFrame(summary);summary.to_csv(HERE/'aggregate_comparison_fmax.csv',index=False)
wing=[]
for (epoch,bins,sel),v in peaks.groupby(['epoch','bins','peak_selection']):
 b=v[v.target=='blue'].iloc[0];r=v[v.target=='red'].iloc[0]
 wing.append({'epoch':epoch,'bins':bins,'peak_selection':sel,'blue_peak_observed_days':b.peak_lag_observed_days,'red_peak_observed_days':r.peak_lag_observed_days,'red_minus_blue_observed_days':r.peak_lag_observed_days-b.peak_lag_observed_days,'red_minus_blue_rest_days':r.peak_lag_rest_days-b.peak_lag_rest_days,'blue_fraction':b.fraction,'red_fraction':r.fraction,'blue_entropy_fraction':b.entropy_fraction,'red_entropy_fraction':r.entropy_fraction,'undefined_zero_peak':b.is_identically_zero or r.is_identically_zero,'weak_nonzero_peak_below_005':b.peak_weak_below_005 or r.peak_weak_below_005})
wing=pd.DataFrame(wing);wing.to_csv(HERE/'wing_contrasts_fmax_gmax.csv',index=False)
common=s[s.config.eq('common')].copy()
group=['epoch','subset','target','bins'];mi=common.loc[common.groupby(group).normalized_leakage.idxmin()];ma=common.loc[common.groupby(group).normalized_leakage.idxmax()]
ext=mi[group+['lag_days','normalized_leakage']].rename(columns={'lag_days':'minimum_lag','normalized_leakage':'minimum_leakage'}).merge(ma[group+['lag_days','normalized_leakage']].rename(columns={'lag_days':'maximum_lag','normalized_leakage':'maximum_leakage'}),on=group)
ext.to_csv(HERE/'common_leakage_extrema.csv',index=False)
ct=[]
for bins,v in ext.groupby('bins'):
 ct.append({'bins':bins,'curves':len(v),'minimum_at_1_day':int(v.minimum_lag.eq(1).sum()),'maximum_at_or_above_20_days':int(v.maximum_lag.ge(20).sum()),'maximum_above_20_days':int(v.maximum_lag.gt(20).sum())})
ct=pd.DataFrame(ct);ct.to_csv(HERE/'common_leakage_counts.csv',index=False)
means=common.groupby(['epoch','subset','bins']).agg(mean_leakage=('normalized_leakage','mean'),min_tuples=('tuple_count','min'),max_tuples=('tuple_count','max')).reset_index();means.to_csv(HERE/'common_mean_leakage_epoch_subset.csv',index=False)
epochmeans=common.groupby(['epoch','bins']).normalized_leakage.mean().rename('mean_leakage').reset_index();epochmeans.to_csv(HERE/'common_mean_leakage_epoch_both_subsets.csv',index=False)
setmeans=common.groupby(['subset','bins']).normalized_leakage.mean().rename('mean_leakage').reset_index();setmeans.to_csv(HERE/'common_mean_leakage_subset_all_epochs.csv',index=False)
summarytxt='''# Exact comparison audit\n\nRedshift z = 0.01717 (Lu and Xi papers). Rest-frame lag = observed-frame lag/(1+z). Every strictly nonzero common-lag U(F) peak is retained; zero plateaus have undefined lag. The flag f<0.05 is only a descriptive weak-peak flag and is never a selection filter or a significance test. Spearman coefficient is computed from ranks only; no new significance test.\n\n## Seasonal f-max comparisons\n\n'''+season.to_string(index=False,float_format=lambda x:f'{x:.8f}')+'\n\n## Aggregate f-max comparisons\n\n'+summary.to_string(index=False,float_format=lambda x:f'{x:.8f}')+'\n\n## Wing contrasts\n\n'+wing[['epoch','bins','peak_selection','red_minus_blue_observed_days','red_minus_blue_rest_days','blue_fraction','red_fraction','undefined_zero_peak','weak_nonzero_peak_below_005']].to_string(index=False,float_format=lambda x:f'{x:.8f}')+'\n\n## Leakage extrema counts\n\n'+ct.to_string(index=False)+'\n\n## Common mean leakage by epoch/subset/bin\n\n'+means.to_string(index=False,float_format=lambda x:f'{x:.8f}')+'\n\n## Common mean leakage, both subsets combined\n\n'+epochmeans.to_string(index=False,float_format=lambda x:f'{x:.8f}')+'\n\n## Common mean leakage, all epochs\n\n'+setmeans.to_string(index=False,float_format=lambda x:f'{x:.8f}')+'\n'
(HERE/'summary.md').write_text(summarytxt)
(HERE/'metadata.json').write_text(json.dumps({'redshift':z,'rest_frame_factor':rest,'selection':'common U(continuum) fraction maximum, all strictly nonzero peaks; zero peaks excluded only because lag undefined','Lu_rest_lags_days':refs.to_dict()},indent=2))
print(season.to_string(index=False,float_format=lambda x:f'{x:.8f}'))
print('\n',summary.to_string(index=False,float_format=lambda x:f'{x:.8f}'))
print('\n',ct.to_string(index=False))
print('\n',means.to_string(index=False,float_format=lambda x:f'{x:.8f}'))
