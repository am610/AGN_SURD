"""Audit saved SURD budgets and matched contrasts; no re-estimation of SURD.

Run: python analyze_extended.py
The contrast sign convention is candidate minus baseline. Subset contrasts
are continuum_wings minus total_wings, matched on the three line targets,
epoch, bins, configuration and base lag. Configuration contrasts are shifted
minus common, matched on epoch, subset, target, bins and base lag. Neither
contrast reruns distributions on identical observation dates; saved tuple
counts are retained explicitly and equal counts do not guarantee equal dates.
"""
from pathlib import Path
import hashlib
import json
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parents[2]/'data'
OUT = Path(__file__).resolve().parent
KEY = ['epoch', 'subset', 'target', 'config', 'bins', 'lag_days']
LINES = ['blue', 'core', 'red']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def contrasts(candidate, baseline, keys, label, metrics):
    """Preserve both operands and signed differences for every metric."""
    q = candidate[keys + metrics].merge(
        baseline[keys + metrics], on=keys, how='inner',
        suffixes=('_candidate', '_baseline'), validate='one_to_one')
    q['contrast'] = label
    for metric in metrics:
        q['delta_' + metric] = q[metric + '_candidate'] - q[metric + '_baseline']
    q['equal_tuple_count'] = q.tuple_count_candidate.eq(q.tuple_count_baseline)
    return q


def contrast_means(q, groups):
    delta = [x for x in q if x.startswith('delta_')]
    out = q.groupby(groups)[delta].mean()
    out['paired_lags'] = q.groupby(groups).size()
    out['equal_count_pairs'] = q.groupby(groups).equal_tuple_count.sum()
    out['count_difference_min'] = q.groupby(groups).delta_tuple_count.min()
    out['count_difference_max'] = q.groupby(groups).delta_tuple_count.max()
    out['leakage_lower_pairs'] = q.groupby(groups).delta_normalized_leakage.apply(lambda x: (x < -1e-12).sum())
    return out.reset_index()


def main():
    a = pd.read_csv(ROOT / 'individual_components.csv.gz')
    s = pd.read_csv(ROOT / 'support_and_leakage.csv')
    assert len(s) == 7200 and len(a) == 7200 * 26
    assert not s.duplicated(KEY).any()
    d = a.merge(s, on=KEY, validate='many_to_one')
    d['g'] = d.fraction * (1 - d.normalized_leakage)
    d['category'] = d.kind
    d.loc[d.kind.eq('U'), 'category'] = 'U_cross'
    d.loc[d.component.eq('U(' + d.target + ')'), 'category'] = 'U_self'
    q = d.groupby(KEY + ['category'])[['fraction', 'g', 'bits']].sum().unstack('category', fill_value=0)
    q.columns = [f'{stat}_{cat}' for stat, cat in q.columns]
    q = q.reset_index().merge(s, on=KEY, validate='one_to_one')
    for stat in ['fraction', 'g', 'bits']:
        q[f'{stat}_U'] = q[f'{stat}_U_self'] + q[f'{stat}_U_cross']
    q['explained_entropy_fraction'] = 1 - q.normalized_leakage
    q['budget_balance_error'] = q.g_U + q.g_R + q.g_S + q.normalized_leakage - 1
    q['observed_fraction_balance_error'] = q.fraction_U + q.fraction_R + q.fraction_S - 1
    q.to_csv(OUT / 'decomposition_budgets.csv', index=False)

    stats = ['g_U_self', 'g_U_cross', 'g_U', 'g_R', 'g_S',
             'fraction_U_self', 'fraction_U_cross', 'fraction_U', 'fraction_R', 'fraction_S',
             'normalized_leakage', 'explained_entropy_fraction', 'tuple_count', 'joint_mi_bits']
    g = ['epoch', 'subset', 'config', 'bins']
    q.groupby(g)[stats].mean().reset_index().to_csv(OUT / 'budget_means_alltargets.csv', index=False)
    q[q.target.isin(LINES)].groupby(g)[stats].mean().reset_index().to_csv(OUT / 'budget_means_line_targets.csv', index=False)
    q.groupby(g + ['target'])[stats].mean().reset_index().to_csv(OUT / 'budget_means_by_target.csv', index=False)

    metrics = ['normalized_leakage', 'g_U_self', 'g_U_cross', 'g_U', 'g_R', 'g_S',
               'fraction_U', 'fraction_R', 'fraction_S', 'tuple_count', 'joint_mi_bits']
    line = q[q.target.isin(LINES)]
    p = contrasts(line[line.subset.eq('continuum_wings')], line[line.subset.eq('total_wings')],
                  ['epoch', 'target', 'config', 'bins', 'lag_days'], 'continuum_minus_total', metrics)
    p.to_csv(OUT / 'subset_paired_by_lag.csv', index=False)
    contrast_means(p, ['epoch', 'target', 'config', 'bins']).to_csv(OUT / 'subset_paired_means_by_target.csv', index=False)
    contrast_means(p, ['epoch', 'config', 'bins']).to_csv(OUT / 'subset_paired_means_by_epoch.csv', index=False)
    contrast_means(p, ['config', 'bins']).to_csv(OUT / 'subset_paired_means_overall.csv', index=False)
    contrast_means(p[p.equal_tuple_count], ['config', 'bins']).to_csv(OUT / 'subset_paired_means_equal_count.csv', index=False)

    base = q[q.config.eq('common')]
    cmp = pd.concat([contrasts(q[q.config.eq(cfg)], base,
             ['epoch', 'subset', 'target', 'bins', 'lag_days'], cfg + '_minus_common', metrics)
             for cfg in ['blue_leading', 'red_leading']], ignore_index=True)
    cmp.to_csv(OUT / 'configuration_paired_by_lag.csv', index=False)
    contrast_means(cmp, ['epoch', 'subset', 'target', 'bins', 'contrast']).to_csv(OUT / 'configuration_paired_means_by_target.csv', index=False)
    contrast_means(cmp, ['epoch', 'subset', 'bins', 'contrast']).to_csv(OUT / 'configuration_paired_means_by_epoch.csv', index=False)
    contrast_means(cmp, ['subset', 'bins', 'contrast']).to_csv(OUT / 'configuration_paired_means_overall.csv', index=False)
    contrast_means(cmp[cmp.target.isin(LINES)], ['subset', 'bins', 'contrast']).to_csv(OUT / 'configuration_paired_means_line_targets.csv', index=False)

    wing = contrasts(q[q.config.eq('blue_leading')], q[q.config.eq('red_leading')],
                     ['epoch', 'subset', 'target', 'bins', 'lag_days'], 'blue_minus_red', metrics)
    wing.to_csv(OUT / 'blue_vs_red_paired_by_lag.csv', index=False)
    contrast_means(wing, ['epoch', 'subset', 'bins']).to_csv(OUT / 'blue_vs_red_paired_means_by_epoch.csv', index=False)
    contrast_means(wing, ['subset', 'bins']).to_csv(OUT / 'blue_vs_red_paired_means_overall.csv', index=False)
    contrast_means(wing[wing.target.isin(LINES)], ['epoch', 'subset', 'target', 'bins']).to_csv(OUT / 'blue_vs_red_paired_means_line_targets.csv', index=False)

    summary = {
        'source_sha256': {n: sha(ROOT / n) for n in ['individual_components.csv.gz', 'support_and_leakage.csv']},
        'script_sha256': sha(Path(__file__)),
        'decompositions': len(q), 'subset_pairs': len(p), 'configuration_pairs': len(cmp),
        'max_budget_balance_error': float(q.budget_balance_error.abs().max()),
        'max_fraction_balance_error': float(q.observed_fraction_balance_error.abs().max()),
        'subset_pairs_equal_tuple_count': int(p.equal_tuple_count.sum()),
        'configuration_pairs_equal_tuple_count': int(cmp.equal_tuple_count.sum()),
        'blue_vs_red_pairs': len(wing),
        'blue_vs_red_equal_tuple_count': int(wing.equal_tuple_count.sum()),
        'mean_convention': 'Unweighted arithmetic means over matched base lags and specified targets; no weighting by tuple count.',
        'support_limitation': 'Same tuple count does not establish same target dates. No identical-date recalculation was performed.',
        'normalization': 'g_C=(1-leakage)*fraction_C; U,R,S are summed before group means.'
    }
    (OUT / 'audit_manifest.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
