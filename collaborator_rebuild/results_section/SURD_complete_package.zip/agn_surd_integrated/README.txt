NGC 5548 seasonal SURD manuscript and component catalogue

Main deliverables
  agn_surd_integrated.tex       Revised paper in the original MNRAS style.
  agn_surd_integrated_refs.bib  Bibliography with the original citation keys.
  agn_surd_integrated.pdf       Visually checked 21-page compiled paper.
  agn_surd_component_supplement.tex / .pdf
                               13-page catalogue containing Tables S1-S14.
  figures/                     Six vector PDF figures and the new figure preview.

Scientific focus
The main paper ranks named U, R and S components for every common-lag
epoch/set/target/bin case. Each atom is selected at its own maximum
g = (1-leakage)*f and reported with simultaneous f, g, leakage and lag.
The top three are ranked within each family. Self-history is separated
from cross-variable unique information. The supplementary catalogue gives
the two self-history panels and all twelve unequal-lag ranking panels.
Full-precision CSVs additionally contain f-maximum rankings and complete
same-lag component snapshots. Different-lag maxima must not be summed.

All four original component figures remain Figures 1-4. Figure 5 is the
new named-component plot. The earlier aggregate budget figure is retained
as Figure A1, with its discussion in Appendix A. Every figure is cited and
interpreted in the text. Appendix B retains the dominant-component table.
Section 3.4 distinguishes SURD causal-discovery questions from the
reverberation observables of Lu and Xi. Section 3.5 gives the astrophysical
interpretation; Section 3.6 discusses leakage and possible missing drivers.

Compile in this directory, keeping figures/ alongside the TeX:
  pdflatex agn_surd_integrated.tex
  bibtex agn_surd_integrated
  pdflatex agn_surd_integrated.tex
  pdflatex agn_surd_integrated.tex
  pdflatex agn_surd_component_supplement.tex
  pdflatex agn_surd_component_supplement.tex
The MNRAS v3.2 class and bibliography style are included. A standard TeX
installation needs newtx, TeX Gyre, amsmath, booktabs, lastpage, ae/aecompl,
capt-of, geometry and hyperref. Main-paper tables are embedded in the TeX.

Reproduce calculations (Python: numpy, pandas, scipy, matplotlib)
  python recalculate_components.py
rebuilds the new atom extrema, rankings, selected tables, named-component
figure and manuscript/supplement TeX. It does not compile the PDFs.
  python recalculate.py
also rebuilds the earlier budget and comparison calculations.
The authoring templates and reproducible revision scripts are in
analysis/component_revision/. previous_manuscript.tex is the archived
pre-revision source used to preserve original figure blocks and tables;
the current manuscript is the root-level agn_surd_integrated.tex.

Data provenance
  Repository: https://github.com/am610/AGN_SURD
  Commit: 895a826512cc2f866035cc5b7b4430e35f28ab44
  Main inputs: data/individual_components.csv.gz and support_and_leakage.csv
The supplied calculations reanalyse archived decompositions, not a new
SURD probability fit. They identify candidate observational causal
influences, shared information and unresolved drivers. Sampling and
estimator diagnostics are retained in Section 3.7 and data/.
Strong redundancy identifies candidate simplifications; whole-predictor
omission is assessed by the conditional-information loss in equation (12).
