from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for name in ['mixed_extended/analyze_extended.py','continuum_extended/analyze.py','comparison_numbers/calculate_comparison.py','generated_tables/build_tables_figures.py','figure_discussion.py']:
    subprocess.run([sys.executable,str(root/'analysis'/name)],check=True,cwd=root)
print('Recalculated archived-data summaries and figure. The manuscript TeX contains its final formatted tables.')

subprocess.run([sys.executable,str(root/'recalculate_components.py')],check=True,cwd=root)
